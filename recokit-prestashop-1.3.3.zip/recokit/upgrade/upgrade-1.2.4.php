<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Asset-only upgrade: product-led comparator layout and cache-busted assets.
 */
function upgrade_module_1_2_4($module)
{
    return true;
}
