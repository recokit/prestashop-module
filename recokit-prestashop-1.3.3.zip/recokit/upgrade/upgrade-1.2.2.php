<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Register cart placement hooks for stores upgrading from 1.2.1 or earlier.
 * PrestaShop does not rerun install() when a module is updated.
 */
function upgrade_module_1_2_2($module)
{
    $ok = true;
    foreach (['displayShoppingCartFooter', 'displayCartModalFooter'] as $hook) {
        if (!$module->isRegisteredInHook($hook)) {
            $ok = $module->registerHook($hook) && $ok;
        }
    }
    return $ok;
}
