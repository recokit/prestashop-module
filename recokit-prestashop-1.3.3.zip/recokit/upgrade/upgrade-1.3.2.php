<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/** Register the dedicated stock-change hook for existing installations. */
function upgrade_module_1_3_2($module)
{
    return $module->isRegisteredInHook('actionUpdateQuantity')
        || $module->registerHook('actionUpdateQuantity');
}
