<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Version 1.3.0 separates the public storefront key from the private
 * integration key. Existing shops must paste the private key shown in their
 * authenticated RecoKit portal before privileged synchronization resumes.
 */
function upgrade_module_1_3_0($module)
{
    return true;
}
