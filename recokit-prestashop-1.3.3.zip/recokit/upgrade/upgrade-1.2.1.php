<?php
/**
 * RecoKit 1.2.1 preserves the shop connection during module reinstalls.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_1($module)
{
    return true;
}
