<?php
/**
 * RecoKit 1.2.0 keeps the same PrestaShop hooks and moves storefront zone
 * presentation settings to the central RecoKit API.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_0($module)
{
    return $module->registerHook('displayShoppingCartFooter')
        && $module->registerHook('displayCartModalFooter');
}
