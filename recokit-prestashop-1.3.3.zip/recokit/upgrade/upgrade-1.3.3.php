<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/** Force PrestaShop to register the bundle/cart widget maintenance release. */
function upgrade_module_1_3_3($module)
{
    return true;
}
