<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Asset-only upgrade: card layout alignment and cache-busted CSS/JS URLs.
 */
function upgrade_module_1_2_3($module)
{
    return true;
}
