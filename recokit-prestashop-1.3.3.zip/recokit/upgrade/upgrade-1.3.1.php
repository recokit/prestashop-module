<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Version 1.3.1 adds the password-setup recovery action for accounts created
 * automatically by the PrestaShop module. No database mutation is required.
 */
function upgrade_module_1_3_1($module)
{
    return true;
}
