/**
 * RecoKit Widget — JavaScript
 * EPIC-PS-03 / US-PS-03.1, US-PS-03.2, US-PS-03.3
 *
 * Chargé sur les pages produit PrestaShop via hookActionFrontControllerSetMedia.
 * Les variables recokitApiKey, recokitProductId, recokitLimit, recokitApiBase
 * sont injectées par le module PHP via Media::addJsDef().
 */
(function () {
  "use strict";

  // Guard against double execution
  if (window.__recokit_widget_initialized) return;
  window.__recokit_widget_initialized = true;

  // ────────────────────────────────────────────────────────────────────────
  //  Configuration (variables injectées par PHP)
  // ────────────────────────────────────────────────────────────────────────
  var API_BASE =
    typeof recokitApiBase !== "undefined"
      ? recokitApiBase
      : "https://api.recokit.fr/api/prestashop";
  var API_KEY = typeof recokitApiKey !== "undefined" ? recokitApiKey : "";
  // Les endpoints recommandations/similaire/comparateur peuvent devoir
  // réveiller une connexion DB tenant ou lire un cache froid. Deux secondes
  // provoquaient trois timeouts simultanés avant même le rendu du widget.
  var API_REQUEST_TIMEOUT_MS = 8000;
  var PRODUCT_ID =
    typeof recokitProductId !== "undefined" ? recokitProductId : "";
  var LIMIT = typeof recokitLimit !== "undefined" ? recokitLimit : 4;
  var CART_PRODUCT_IDS =
    typeof recokitCartProductIds !== "undefined" &&
    Array.isArray(recokitCartProductIds)
      ? recokitCartProductIds.map(String)
      : [];
  var COOKIE = "_recokit_session";

  // Reprendre les conventions visuelles du thème PrestaShop pour les CTA.
  // Les valeurs calculées deviennent des variables CSS et gardent le fallback
  // neutre de widget.css si aucun bouton natif n'est détectable.
  function adoptThemeButtonStyles() {
    var selectors = [
      '[data-button-action="add-to-cart"]',
      'button.add-to-cart',
      '.add-to-cart',
      '.btn-primary',
      'button[type="submit"]'
    ];
    var source = null;
    for (var i = 0; i < selectors.length && !source; i++) {
      var candidates = document.querySelectorAll(selectors[i]);
      for (var j = 0; j < candidates.length; j++) {
        if (!candidates[j].closest(".recokit-widget")) {
          source = candidates[j];
          break;
        }
      }
    }
    if (!source || !window.getComputedStyle) return;
    var style = window.getComputedStyle(source);
    var root = document.documentElement;
    if (style.backgroundColor && style.backgroundColor !== "transparent") {
      root.style.setProperty("--recokit-primary", style.backgroundColor);
    }
    if (style.color && style.color !== "transparent") {
      root.style.setProperty("--recokit-atc-text", style.color);
    }
    if (style.borderRadius) root.style.setProperty("--recokit-atc-radius", style.borderRadius);
    if (style.fontFamily) root.style.setProperty("--recokit-font", style.fontFamily);
    if (style.fontWeight) root.style.setProperty("--recokit-atc-font-weight", style.fontWeight);
  }

  // Paramètres d'affichage configurés centralement dans le dashboard RecoKit
  // (onglet « Apparence ») et transmis par l'API dans `display_settings`.
  var displaySettings = {
    display_mode: "grid", // 'grid' | 'carousel'
    grid_columns: null, // colonnes fixes en mode grille, tableau N×M (null = responsive du thème)
    enable_add_to_cart: true,
    zones: null, // liste ordonnée [{type, enabled}] (null = comportement historique)
    dedupe: true, // éviter qu'un même produit apparaisse dans plusieurs zones
    cart_modal_recommendations: true,
  };

  // Produits déjà affichés (déduplication inter-zones, ordre = ordre des zones)
  var displayedProductIds = {};

  function isProductAvailable(rec) {
    if (displaySettings.show_out_of_stock === true) return true;
    if (!rec || (rec.inventory_quantity == null && !Array.isArray(rec.variants))) {
      // Anciennes réponses API : ne pas masquer les cartes dépourvues de
      // métadonnées de stock.
      return true;
    }
    if (rec.inventory_quantity != null) {
      var quantity = parseInt(rec.inventory_quantity, 10);
      if (!isNaN(quantity)) return quantity > 0;
    }
    if (Array.isArray(rec.variants) && rec.variants.length) {
      return rec.variants.some(function (variant) {
        var value = variant && (variant.inventory_quantity != null
          ? variant.inventory_quantity : variant.quantity);
        return value != null && parseInt(value, 10) > 0;
      });
    }
    return true;
  }

  function applyDedupe(recommendations) {
    if (!displaySettings.dedupe) return recommendations;
    var kept = [];
    (recommendations || []).forEach(function (rec) {
      if (!isProductAvailable(rec)) return;
      var id = String(rec.id || "");
      if (!id || displayedProductIds[id]) return;
      displayedProductIds[id] = true;
      kept.push(rec);
    });
    return kept;
  }

  // Select only what will actually be rendered. This prevents hidden
  // candidates from being registered as displayed and starving later zones.
  function takeUnique(recommendations, limit) {
    var kept = [];
    (recommendations || []).forEach(function (rec) {
      if (kept.length >= limit) return;
      if (!isProductAvailable(rec)) return;
      var id = String(rec.id || "");
      if (!id || (displaySettings.dedupe && displayedProductIds[id])) return;
      if (displaySettings.dedupe) displayedProductIds[id] = true;
      kept.push(rec);
    });
    return kept;
  }

  function isZoneEnabled(type) {
    // Pas de config de zones (ancien backend) : comportement historique
    // (widget principal + similaires activés, comparateur tenté puis masqué sur 403).
    if (!displaySettings.zones) return true;
    for (var i = 0; i < displaySettings.zones.length; i++) {
      if (displaySettings.zones[i] && displaySettings.zones[i].type === type) {
        return !!displaySettings.zones[i].enabled;
      }
    }
    return false;
  }

  function zoneOrder(type) {
    // Position de la zone dans l'ordre configuré (-1 si absente).
    if (!displaySettings.zones) return type === "complementary" ? 0 : 1;
    for (var i = 0; i < displaySettings.zones.length; i++) {
      if (displaySettings.zones[i] && displaySettings.zones[i].type === type) {
        return i;
      }
    }
    return -1;
  }

  function zoneLimit(type) {
    if (!displaySettings.zones) return LIMIT;
    for (var i = 0; i < displaySettings.zones.length; i++) {
      var zone = displaySettings.zones[i];
      if (zone && zone.type === type) {
        var value = parseInt(zone.limit, 10);
        return isNaN(value) ? LIMIT : Math.max(1, Math.min(value, 50));
      }
    }
    return LIMIT;
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Helpers
  // ────────────────────────────────────────────────────────────────────────

  function getCookie(name) {
    var match = document.cookie.match(
      new RegExp("(?:^|; )" + name + "=([^;]*)"),
    );
    return match ? decodeURIComponent(match[1]) : null;
  }

  function generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0;
        var v = c === "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      },
    );
  }

  function ensureSession() {
    var session = getCookie(COOKIE);
    if (!session) {
      session = generateUUID();
      var expires = new Date(
        Date.now() + 30 * 24 * 60 * 60 * 1000,
      ).toUTCString();
      document.cookie =
        COOKIE +
        "=" +
        session +
        "; expires=" +
        expires +
        "; path=/; SameSite=Lax; Secure";
    }
    return session;
  }

  // Vérifie le consentement RGPD (compatible Cookiebot et Axeptio)
  function hasConsent() {
    if (typeof Cookiebot !== "undefined" && Cookiebot.consent) {
      return Cookiebot.consent.statistics === true;
    }
    if (typeof window.__axeptio_cookies !== "undefined") {
      return window.__axeptio_cookies.analytics === true;
    }
    // Si aucun outil de consentement détecté, on autorise (opt-in implicite)
    return true;
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Récupération des recommandations via l'API RecoKit
  // ────────────────────────────────────────────────────────────────────────

  function fetchRecommendations(productId, limit, sessionId, callback) {
    var url =
      API_BASE +
      "/recommendations" +
      "?product_id=" +
      encodeURIComponent(productId) +
      "&limit=" +
      limit;

    if (sessionId) {
      url += "&session=" + encodeURIComponent(sessionId);
    }
    url +=
      "&lang=" +
      encodeURIComponent((document.documentElement.lang || "fr").slice(0, 2));

    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("X-Api-Key", API_KEY);
    xhr.timeout = API_REQUEST_TIMEOUT_MS;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var data = JSON.parse(xhr.responseText);
          // Paramètres d'affichage centraux (dashboard « Apparence »)
          if (data.display_settings) {
            displaySettings = {
              display_mode: data.display_settings.display_mode || "grid",
              grid_columns: data.display_settings.grid_columns || null,
              enable_add_to_cart:
                data.display_settings.enable_add_to_cart !== false,
              zones: Array.isArray(data.display_settings.zones)
                ? data.display_settings.zones
                : null,
              dedupe: data.display_settings.dedupe !== false,
              cart_modal_recommendations: data.display_settings.cart_modal_recommendations !== false,
              show_out_of_stock: data.display_settings.show_out_of_stock === true,
              personalization_enabled:
                data.display_settings.personalization_enabled === true,
            };
          }
          callback(null, data);
        } catch (e) {
          callback(e, null);
        }
      } else {
        callback(new Error("HTTP " + xhr.status), []);
      }
    };

    xhr.onerror = function () {
      callback(new Error("Network error"), []);
    };
    xhr.ontimeout = function () {
      callback(new Error("Timeout (" + API_REQUEST_TIMEOUT_MS + "ms)"), []);
    };

    xhr.send();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Récupération des produits similaires via l'API RecoKit
  // ────────────────────────────────────────────────────────────────────────

  function fetchWidgetZones(productId, sessionId, callback) {
    var url = API_BASE + "/widget?product_id=" + encodeURIComponent(productId)
      + "&limit=50&lang=" + encodeURIComponent((document.documentElement.lang || "fr").slice(0, 2));
    if (sessionId) url += "&session=" + encodeURIComponent(sessionId);
    if (CART_PRODUCT_IDS.length) url += "&cart_product_ids=" + encodeURIComponent(CART_PRODUCT_IDS.join(","));
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("X-Api-Key", API_KEY);
    xhr.timeout = API_REQUEST_TIMEOUT_MS;
    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try { callback(null, JSON.parse(xhr.responseText)); } catch (e) { callback(e, null); }
      } else callback(new Error("HTTP " + xhr.status), null);
    };
    xhr.onerror = function () { callback(new Error("Network error"), null); };
    xhr.ontimeout = function () { callback(new Error("Timeout (" + API_REQUEST_TIMEOUT_MS + "ms)"), null); };
    xhr.send();
  }

  function fetchSimilar(productId, limit, excludeIds, callback) {
    var url =
      API_BASE +
      "/similar" +
      "?product_id=" +
      encodeURIComponent(productId) +
      "&limit=" +
      limit;
    if (excludeIds && excludeIds.length) url += "&exclude_ids=" + encodeURIComponent(excludeIds.join(","));

    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("X-Api-Key", API_KEY);
    xhr.timeout = API_REQUEST_TIMEOUT_MS;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var data = JSON.parse(xhr.responseText);
          callback(null, data.recommendations || []);
        } catch (e) {
          callback(e, []);
        }
      } else {
        callback(new Error("HTTP " + xhr.status), []);
      }
    };

    xhr.onerror = function () {
      callback(new Error("Network error"), []);
    };
    xhr.ontimeout = function () {
      callback(new Error("Timeout (" + API_REQUEST_TIMEOUT_MS + "ms)"), []);
    };

    xhr.send();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Récupération du comparateur via l'API RecoKit (Pro uniquement)
  //  Sur 403 (offre non-Pro), le widget comparateur est masqué silencieusement.
  // ────────────────────────────────────────────────────────────────────────

  function fetchComparator(productId, limit, excludeIds, callback) {
    var url =
      API_BASE +
      "/comparator" +
      "?product_id=" +
      encodeURIComponent(productId) +
      "&limit=" +
      limit;
    if (excludeIds && excludeIds.length) url += "&exclude_ids=" + encodeURIComponent(excludeIds.join(","));

    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("X-Api-Key", API_KEY);
    xhr.timeout = API_REQUEST_TIMEOUT_MS;

    xhr.onload = function () {
      // 403 = offre non-Pro → on masque le comparateur silencieusement
      if (xhr.status === 403) {
        callback({ status: 403, silent: true }, []);
        return;
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var data = JSON.parse(xhr.responseText);
          callback(null, data.recommendations || []);
        } catch (e) {
          callback(e, []);
        }
      } else {
        callback(new Error("HTTP " + xhr.status), []);
      }
    };

    xhr.onerror = function () {
      callback(new Error("Network error"), []);
    };
    xhr.ontimeout = function () {
      callback(new Error("Timeout (" + API_REQUEST_TIMEOUT_MS + "ms)"), []);
    };

    xhr.send();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Récupération du bundle 1-clic via l'API RecoKit
  //  (widget composite « Complétez votre équipement », table product_bundles)
  // ────────────────────────────────────────────────────────────────────────

  function fetchBundle(productId, limit, callback) {
    var url =
      API_BASE +
      "/bundle" +
      "?product_id=" +
      encodeURIComponent(productId) +
      "&limit=" +
      limit;

    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.setRequestHeader("X-Api-Key", API_KEY);
    xhr.timeout = API_REQUEST_TIMEOUT_MS;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var data = JSON.parse(xhr.responseText);
          callback(null, data.bundle || null);
        } catch (e) {
          callback(e, null);
        }
      } else {
        callback(new Error("HTTP " + xhr.status), null);
      }
    };

    xhr.onerror = function () {
      callback(new Error("Network error"), null);
    };
    xhr.ontimeout = function () {
      callback(new Error("Timeout (" + API_REQUEST_TIMEOUT_MS + "ms)"), null);
    };

    xhr.send();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Rendu du widget
  // ────────────────────────────────────────────────────────────────────────

  // Libellés i18n du bouton d'ajout au panier
  function atcLabels() {
    var lang = (document.documentElement.lang || "en").slice(0, 2).toLowerCase();
    return lang === "fr"
      ? { add: "Ajouter au panier", adding: "Ajout…", added: "\u2713 Ajout\u00e9", error: "Erreur" }
      : { add: "Add to cart", adding: "Adding\u2026", added: "\u2713 Added", error: "Error" };
  }

  function showCartToast(message) {
    var lang = (document.documentElement.lang || "fr").slice(0, 2).toLowerCase();
    var msg = message || (lang === "fr" ? "✓ Produit ajouté au panier !" : "✓ Product added to cart!");
    var toast = document.getElementById("recokit-cart-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "recokit-cart-toast";
      toast.style.cssText = "position:fixed;right:24px;bottom:24px;z-index:2147483647;background:#10b981;color:#ffffff;padding:14px 22px;border-radius:8px;font-size:14px;font-weight:600;box-shadow:0 10px 25px rgba(0,0,0,.25);transition:opacity 0.3s ease, transform 0.3s ease;transform:translateY(0);pointer-events:none;";
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = "1";
    toast.style.transform = "translateY(0)";
    clearTimeout(window.__recokitToastTimer);
    window.__recokitToastTimer = setTimeout(function () {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
    }, 3500);
  }

  // Ajout direct au panier (contrôleur cart de PrestaShop 1.7/8).
  // Le token statique est exposé par le cœur sur les pages produit
  // (Media::addJsDef) ; fallback sans token pour les configurations
  // l'ayant désactivé.
  function getCartToken() {
    if (typeof window.static_token !== "undefined" && window.static_token) {
      return window.static_token;
    }
    if (typeof prestashop !== "undefined") {
      if (prestashop.static_token) return prestashop.static_token;
      if (prestashop.token) return prestashop.token;
    }
    var tokenInput = document.querySelector(
      'input[name="token"], input[name="static_token"]'
    );
    return tokenInput ? tokenInput.value : "";
  }

  function addToCart(productId, btn) {
    if (!productId || (btn && btn.disabled)) return;
    var labels = atcLabels();
    if (btn) {
      btn.disabled = true;
      btn.textContent = labels.adding;
      btn.classList.remove("is-added", "is-error");
    }

    var cartUrl = "";
    if (typeof prestashop !== "undefined" && prestashop.urls && prestashop.urls.pages && prestashop.urls.pages.cart) {
      cartUrl = prestashop.urls.pages.cart;
    } else if (typeof prestashop !== "undefined" && prestashop.urls && prestashop.urls.base_url) {
      cartUrl = prestashop.urls.base_url + "index.php?controller=cart";
    } else {
      cartUrl = window.location.origin + "/index.php?controller=cart";
    }

    var token = getCartToken();
    var formData = new FormData();
    formData.append("ajax", "1");
    formData.append("action", "update");
    formData.append("add", "1");
    formData.append("id_product", String(productId));
    formData.append("id_product_attribute", "0");
    formData.append("qty", "1");
    if (token) formData.append("token", token);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", cartUrl, true);
    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
    xhr.onload = function () {
      var ok = false;
      try {
        var resp = JSON.parse(xhr.responseText);
        ok = (xhr.status >= 200 && xhr.status < 300) && (!resp.hasError && (!resp.errors || resp.errors.length === 0));
      } catch (e) {
        ok = (xhr.status >= 200 && xhr.status < 300);
      }

      if (ok) {
        if (btn) {
          btn.textContent = labels.added;
          btn.classList.add("is-added");
        }
        showCartToast();
        // If the theme exposes its add-to-cart modal, refresh the cart
        // recommendation block with the product just added.
        refreshCartWidgets(String(productId));
        // PrestaShop themes often create #blockcart-modal asynchronously
        // after updateCart. Retry once after the modal DOM exists.
        setTimeout(function () { refreshCartWidgets(String(productId)); }, 500);
        setTimeout(function () { refreshCartWidgets(String(productId)); }, 1500);
        if (typeof prestashop !== "undefined" && typeof prestashop.emit === "function") {
          try {
            prestashop.emit("updateCart", {
              reason: { idProduct: productId, idProductAttribute: 0, linkAction: "add-to-cart" },
              resp: resp || {},
            });
          } catch (err) {}
        }
      } else {
        console.warn("[RecoKit] Ajout panier refusé", xhr.status, xhr.responseText);
        if (btn) {
          btn.textContent = labels.error;
          btn.classList.add("is-error");
        }
      }

      if (btn) {
        setTimeout(function () {
          btn.disabled = false;
          btn.textContent = labels.add;
          btn.classList.remove("is-added", "is-error");
        }, 2500);
      }
    };
    xhr.onerror = function () {
      if (btn) {
        btn.textContent = labels.error;
        btn.classList.add("is-error");
        setTimeout(function () {
          btn.disabled = false;
          btn.textContent = labels.add;
          btn.classList.remove("is-error");
        }, 2500);
      }
    };
    xhr.send(formData);
  }

  function renderCard(rec, extraHtml) {
    var img = rec.image_url
      ? '<img src="' +
        rec.image_url +
        '" alt="' +
        escapeHtml(rec.name) +
        '" loading="lazy" style="width:100%; height:auto;">'
      : '<div style="background:#e9ecef; width:100%; aspect-ratio:1/1;"></div>';

    var price = rec.price
      ? '<div class="product-price-and-shipping"><span class="price">' +
        rec.price +
        " €</span></div>"
      : "";

    var explanation = rec.explanation
      ? '<div style="font-size: 11px; color: #666; margin-top: 6px; line-height: 1.3; font-style: italic;">' +
        rec.explanation +
        "</div>"
      : "";

    function str2url(str) {
      str = str.toLowerCase();
      str = str.replace(/[àáâãäå]/g, "a");
      str = str.replace(/[èéêë]/g, "e");
      str = str.replace(/[ìíîï]/g, "i");
      str = str.replace(/[òóôõö]/g, "o");
      str = str.replace(/[ùúûü]/g, "u");
      str = str.replace(/[ç]/g, "c");
      str = str.replace(/[^a-z0-9]/g, "-");
      str = str.replace(/-+/g, "-");
      str = str.replace(/^-|-$/g, "");
      return str;
    }

    // Support pour les URLs PrestaShop natives
    var base =
      typeof prestashop !== "undefined" && prestashop.urls
        ? prestashop.urls.base_url
        : window.location.origin + "/";
    var langParam = "";
    if (
      typeof window !== "undefined" &&
      window.location &&
      window.location.search
    ) {
      var match = window.location.search.match(/id_lang=([0-9]+)/);
      if (match) langParam = "&id_lang=" + match[1];
    }

    var productUrl =
      rec.product_url ||
      base +
        "index.php?id_product=" +
        rec.id +
        "&rewrite=" +
        str2url(rec.name) +
        "&controller=product" +
        langParam;

    // Bouton d'ajout au panier direct (hors des <a> — HTML valide)
    var atc = "";
    var recId = rec.id || rec.product_id;
    var enableAtc = displaySettings.enable_add_to_cart !== false;
    if (enableAtc && recId) {
      atc =
        '<button type="button" class="recokit-atc" style="margin-top:auto;" data-recokit-add="' +
        escapeHtml(String(recId)) +
        '">' +
        atcLabels().add +
        "</button>";
    }

    return (
      '<article class="product-miniature js-product-miniature" data-id-product="' +
      rec.id +
      '" data-id-product-attribute="0">' +
      '<div class="thumbnail-container">' +
      '<div class="thumbnail-top">' +
      '<a href="' +
      productUrl +
      '" class="thumbnail product-thumbnail" data-recokit-id="' +
      rec.id +
      '">' +
      img +
      "</a>" +
      "</div>" +
      '<div class="product-description" style="display:flex;flex-direction:column;height:100%;">' +
      '<h2 class="h3 product-title"><a href="' +
      productUrl +
      '">' +
      escapeHtml(rec.name) +
      "</a></h2>" +
      price +
      explanation +
      (extraHtml || "") +
      atc +
      "</div>" +
      "</div>" +
      "</article>"
    );
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Mode carrousel + ajout panier (paramètres centraux display_settings)
  // ────────────────────────────────────────────────────────────────────────

  function setupCarousel(widget, grid) {
    widget.classList.add("recokit-carousel");
    grid.classList.add("recokit-carousel-track");

    var prev = document.createElement("button");
    prev.type = "button";
    prev.className = "recokit-carousel-btn recokit-carousel-prev";
    prev.setAttribute("aria-label", "Previous");
    prev.innerHTML = "\u2039";

    var next = document.createElement("button");
    next.type = "button";
    next.className = "recokit-carousel-btn recokit-carousel-next";
    next.setAttribute("aria-label", "Next");
    next.innerHTML = "\u203a";

    grid.parentNode.insertBefore(prev, grid);
    if (grid.nextSibling) {
      grid.parentNode.insertBefore(next, grid.nextSibling);
    } else {
      grid.parentNode.appendChild(next);
    }

    function step() {
      var item = grid.querySelector(".product-miniature");
      var gap = parseFloat(window.getComputedStyle(grid).gap) || 0;
      var basis = item
        ? item.getBoundingClientRect().width
        : grid.clientWidth * 0.8;
      return basis + gap;
    }

    function update() {
      prev.disabled = grid.scrollLeft <= 2;
      next.disabled =
        grid.scrollLeft + grid.clientWidth >= grid.scrollWidth - 2;
    }

    prev.addEventListener("click", function () {
      grid.scrollBy({ left: -step(), behavior: "smooth" });
    });
    next.addEventListener("click", function () {
      grid.scrollBy({ left: step(), behavior: "smooth" });
    });
    grid.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    update();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Mise en page par zone (config « zones » du dashboard) : chaque zone grille
  //  peut surcharger le style (grid/carousel) et le nombre de colonnes ;
  //  null/absent = hérite du réglage global « Mise en page du widget ».
  // ────────────────────────────────────────────────────────────────────────

  function zoneConfig(zoneType) {
    if (!zoneType || !Array.isArray(displaySettings.zones)) return null;
    for (var i = 0; i < displaySettings.zones.length; i++) {
      if (displaySettings.zones[i] && displaySettings.zones[i].type === zoneType) {
        return displaySettings.zones[i];
      }
    }
    return null;
  }

  function zoneDisplayMode(zoneType) {
    var zone = zoneConfig(zoneType);
    if (zone && (zone.display_mode === "grid" || zone.display_mode === "carousel")) {
      return zone.display_mode;
    }
    return displaySettings.display_mode === "carousel" ? "carousel" : "grid";
  }

  function zoneGridColumns(zoneType) {
    var zone = zoneConfig(zoneType);
    var cols;
    if (zone) {
      cols = parseInt(zone.grid_columns, 10);
      if (cols >= 1 && cols <= 8) return cols;
    }
    cols = parseInt(displaySettings.grid_columns, 10);
    return cols >= 1 && cols <= 8 ? cols : null;
  }

  // Nombre de colonnes fixe en mode grille. null/0 → le thème garde ses
  // breakpoints responsive (2/3/4). Dans les zones panier, seules les
  // colonnes explicites de la zone s'appliquent (jamais le réglage global :
  // la popup d'ajout reste compacte par défaut).
  function applyGridLayout(grid, cols, cartContext) {
    if (!grid) return;
    if (cartContext && !grid.closest(".recokit-cart-recommendations")) {
      cartContext = false;
    }
    if (cols >= 1 && cols <= 8) {
      grid.style.setProperty(
        "grid-template-columns",
        "repeat(" + cols + ", minmax(0, 1fr))",
      );
    } else if (!cartContext) {
      grid.style.removeProperty("grid-template-columns");
    }
  }

  // Applique les paramètres d'affichage (carrousel + bouton panier) à une zone
  function enhanceWidget(widget, grid, zoneType) {
    var cartContext = !!(zoneType && zoneType.indexOf("cart_") === 0);
    if (zoneDisplayMode(zoneType) === "carousel") {
      setupCarousel(widget, grid);
    } else {
      var zone = zoneConfig(zoneType);
      // Colonnes : explicites de zone partout ; globales hors zones panier.
      applyGridLayout(
        grid,
        zoneGridColumns(zoneType),
        cartContext && !(zone && zone.grid_columns),
      );
    }
    // Ajout au panier direct (délégation — les boutons portent data-recokit-add)
    grid.addEventListener("click", function (e) {
      var btn = e.target.closest(".recokit-atc");
      if (btn && !btn.disabled) {
        e.preventDefault();
        e.stopPropagation();
        addToCart(btn.getAttribute("data-recokit-add"), btn);
      }
    }, true);
  }

  function renderWidget(recommendations) {
    var widget = document.getElementById("recokit-widget");
    var skeleton = widget
      ? widget.querySelector(".recokit-widget__skeleton")
      : null;
    var grid = widget ? widget.querySelector(".recokit-widget__grid") : null;

    if (!widget || !grid) return;

    // Masquer le skeleton
    if (skeleton) skeleton.style.display = "none";

    if (!recommendations || recommendations.length === 0) {
      // Aucune reco → widget masqué (graceful degradation)
      widget.style.display = "none";
      return;
    }

    // Remplir la grille
    var html = "";
    recommendations.forEach(function (rec) {
      html += renderCard(rec);
    });
    grid.innerHTML = html;
    widget.style.display = "";

    // Paramètres d'affichage (carrousel + ajout panier) — zone « Vous aimerez aussi »
    enhanceWidget(widget, grid, "complementary");

    // Tracking des clics sur une reco
    grid.addEventListener("click", function (e) {
      var link = e.target.closest("[data-recokit-id]");
      if (link) {
        trackClick(link.getAttribute("data-recokit-id"));
      }
    });
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Rendu générique (similaires + comparateur) — évite de dupliquer la logique
  //  de skeleton / grille / tracking déjà présente dans renderWidget.
  // ────────────────────────────────────────────────────────────────────────

  function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function characteristicLabel(key) {
    var lang = (document.documentElement.lang || "fr").slice(0, 2).toLowerCase();
    var labels = {
      fr: {
        capacity: "Capacité", volume: "Volume", dimensions: "Dimensions",
        dimension_h: "Hauteur", dimension_l: "Longueur", dimension_w: "Largeur",
        material: "Matière", warranty: "Garantie", power: "Puissance",
        flow_rate: "Débit", weight: "Poids", color: "Couleur"
      },
      en: {
        capacity: "Capacity", volume: "Volume", dimensions: "Dimensions",
        dimension_h: "Height", dimension_l: "Length", dimension_w: "Width",
        material: "Material", warranty: "Warranty", power: "Power",
        flow_rate: "Flow rate", weight: "Weight", color: "Color"
      }
    };
    var normalized = String(key || "").toLowerCase().trim();
    if (labels[lang] && labels[lang][normalized]) return labels[lang][normalized];
    return normalized.replace(/[_-]+/g, " ").replace(/\b\w/g, function (m) { return m.toUpperCase(); });
  }

  function characteristicRank(key) {
    var order = { capacity: 1, volume: 2, dimensions: 3, dimension_l: 4,
      dimension_w: 5, dimension_h: 6, power: 7, flow_rate: 8, material: 20,
      warranty: 30, weight: 40, color: 50 };
    return order[String(key || "").toLowerCase().trim()] || 100;
  }

  function renderComparatorTable(recommendations) {
    if (!recommendations || recommendations.length === 0) return "";
    var pageLang = (document.documentElement.lang || "fr").slice(0, 2).toLowerCase();
    var sourceName = pageLang === "fr" ? "Produit source" : "Source product";
    var title = document.querySelector("h1");
    if (title && title.textContent.trim()) sourceName = title.textContent.trim();
    var sourcePrice = "";
    var sourcePriceEl = document.querySelector(
      '[itemprop="price"], .current-price .price, .product-price'
    );
    if (sourcePriceEl && sourcePriceEl.textContent.trim()) {
      sourcePrice = sourcePriceEl.textContent.trim();
    }
    var sourceImage = "";
    var sourceImageEl = document.querySelector(
      '.product-cover img, .product-images img[itemprop="image"], img[itemprop="image"]'
    );
    var sourceImageMeta = document.querySelector('meta[property="og:image"]');
    if (sourceImageEl) {
      sourceImage = sourceImageEl.currentSrc || sourceImageEl.src || sourceImageEl.getAttribute("data-src") || "";
    } else if (sourceImageMeta) {
      sourceImage = sourceImageMeta.getAttribute("content") || "";
    }
    var byKey = {};
    recommendations.forEach(function (rec) {
      (rec.characteristics || []).forEach(function (c) {
        var key = String(c.key || "").toLowerCase().trim();
        if (key && !byKey[key]) byKey[key] = { key: c.key, source_value: c.source_value };
      });
    });
    var rows = Object.keys(byKey).sort(function (a, b) {
      return characteristicRank(a) - characteristicRank(b) || a.localeCompare(b);
    }).map(function (key) {
      var row = byKey[key];
      var values = recommendations.map(function (rec) {
        var c = (rec.characteristics || []).find(function (item) {
          return String(item.key || "").toLowerCase().trim() === key;
        });
        if (!c) return '<td class="recokit-comparator-value recokit-comparator-value--empty">—</td>';
        var mark = c.is_matching === true ? " ✓" : c.is_matching === false ? " ✗" : "";
        var color = c.is_matching === true ? "#2bbd63" : c.is_matching === false ? "#d9534f" : "inherit";
        return '<td class="recokit-comparator-value" style="color:' + color + ';">' + escapeHtml(c.recommended_value) + mark + "</td>";
      }).join("");
      return '<tr><th scope="row" class="recokit-comparator-feature">' +
        escapeHtml(characteristicLabel(row.key)) + '</th><td class="recokit-comparator-value">' +
        escapeHtml(row.source_value) + "</td>" + values + "</tr>";
    }).join("");
    var headers = recommendations.map(function (rec) {
      var atc = displaySettings.enable_add_to_cart && rec.id ?
        '<button type="button" class="recokit-atc" data-recokit-add="' + escapeHtml(String(rec.id)) + '">' + atcLabels().add + '</button>' : "";
      return '<th class="recokit-comparator-product"><div class="recokit-comparator-product__card">' +
        (rec.image_url ? '<img src="' + escapeHtml(rec.image_url) + '" alt="' + escapeHtml(rec.name) + '" loading="lazy">' : '<span class="recokit-comparator-product__image-placeholder"></span>') +
        '<a class="recokit-comparator-product__name" href="' + escapeHtml(rec.product_url || "#") + '" data-recokit-id="' + escapeHtml(String(rec.id)) + '">' + escapeHtml(rec.name) + '</a>' +
        (rec.price ? '<div class="price recokit-comparator-product__price">' + escapeHtml(rec.price) + ' €</div>' : "") + '<div class="recokit-comparator-product__action">' + atc + '</div></div></th>';
    }).join("");
    var sourceAtc = displaySettings.enable_add_to_cart
      ? '<button type="button" class="recokit-atc" data-recokit-add="' +
        escapeHtml(String(PRODUCT_ID)) + '">' + atcLabels().add + '</button>'
      : "";
    var sourceHeader = '<th class="recokit-comparator-product recokit-comparator-product--source"><div class="recokit-comparator-product__eyebrow">' +
      escapeHtml(pageLang === "fr" ? "Votre article" : "Your product") + '</div><div class="recokit-comparator-product__card">' +
      (sourceImage ? '<img src="' + escapeHtml(sourceImage) + '" alt="' + escapeHtml(sourceName) + '">' : '<span class="recokit-comparator-product__image-placeholder"></span>') +
      '<strong class="recokit-comparator-product__name">' + escapeHtml(sourceName) + '</strong>' +
      (sourcePrice ? '<div class="price">' + escapeHtml(sourcePrice) + '</div>' : "") +
      '<div class="recokit-comparator-product__action">' + sourceAtc + '</div></div></th>';
    return '<div class="recokit-comparator-table-wrap"><table class="recokit-comparator-table">' +
      '<thead><tr><th class="recokit-comparator-corner" aria-hidden="true"></th>' + sourceHeader + headers + '</tr></thead>' +
      '<tbody>' + rows + '</tbody></table></div>';
  }

  function renderIntoWidget(containerId, recommendations, cardBuilder, zoneType) {
    var widget = document.getElementById(containerId);
    var skeleton = widget
      ? widget.querySelector(".recokit-widget__skeleton")
      : null;
    var grid = widget ? widget.querySelector(".recokit-widget__grid") : null;

    if (!widget || !grid) return;

    // Masquer le skeleton
    if (skeleton) skeleton.style.display = "none";

    if (!recommendations || recommendations.length === 0) {
      // Aucun résultat → widget masqué (graceful degradation)
      widget.style.display = "none";
      return;
    }

    // Remplir la grille
    var html = "";
    recommendations.forEach(function (rec) {
      html += cardBuilder(rec);
    });
    grid.innerHTML = html;
    widget.style.display = "";

    // Paramètres d'affichage (carrousel + ajout panier) — zone dédiée
    enhanceWidget(widget, grid, zoneType);

    // Tracking des clics sur une reco
    grid.addEventListener("click", function (e) {
      var link = e.target.closest("[data-recokit-id]");
      if (link) {
        trackClick(link.getAttribute("data-recokit-id"));
      }
    });
  }

  function renderSimilarWidget(recommendations) {
    renderIntoWidget("recokit-similar-widget", recommendations, renderCard, "similar");
  }

  function renderComparatorWidget(recommendations) {
    var widget = document.getElementById("recokit-comparator-widget");
    var skeleton = widget && widget.querySelector(".recokit-widget__skeleton");
    var grid = widget && widget.querySelector(".recokit-widget__grid");
    if (!widget || !grid) return;
    if (skeleton) skeleton.style.display = "none";
    if (!recommendations || recommendations.length === 0) { widget.style.display = "none"; return; }
    grid.innerHTML = renderComparatorTable(recommendations);
    widget.style.display = "";
    enhanceWidget(widget, grid);
    // Bind directly as well as through delegation: some PrestaShop themes
    // stop propagation on table controls.
    grid.querySelectorAll(".recokit-atc").forEach(function (btn) {
      btn.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        addToCart(btn.getAttribute("data-recokit-add"), btn);
      }, true);
    });
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Bundle 1-clic : widget composite avec cases à cocher + sous-total dynamique
  // ────────────────────────────────────────────────────────────────────────

  function bundleLabels() {
    var lang = (document.documentElement.lang || "en").slice(0, 2).toLowerCase();
    return lang === "fr"
      ? {
          title: "Complétez votre équipement",
          current: "Produit actuel",
          subtotal: "Sous-total",
          addAll: "Tout ajouter au panier",
          adding: "Ajout…",
          added: "\u2713 Ajouté",
          error: "Erreur",
        }
      : {
          title: "Complete your setup",
          current: "Current product",
          subtotal: "Subtotal",
          addAll: "Add all to cart",
          adding: "Adding…",
          added: "\u2713 Added",
          error: "Error",
        };
  }

  function formatMoney(sampleFormatted, value) {
    // Conserve la convention de prix de la boutique (préfixe/suffixe €).
    var sample = String(sampleFormatted || "");
    var match = sample.match(/^([^\d.,]*)([\d.,]+)(.*)$/);
    var suffix = !!(match && match[3] && match[3].trim());
    var symbol = match ? (match[1] || match[3] || "€").trim() : "€";
    var fixed = (Math.round(value * 100) / 100).toFixed(2);
    return suffix ? fixed + "\u00a0" + symbol : symbol + fixed;
  }

  function renderBundleWidget(bundle) {
    var widget = document.getElementById("recokit-bundle-widget");
    if (!widget) return;

    var skeleton = widget.querySelector(".recokit-widget__skeleton");
    var content = widget.querySelector(".recokit-bundle-widget__content");
    if (!content) return;

    if (skeleton) skeleton.style.display = "none";

    if (
      !bundle ||
      !bundle.source_product ||
      !bundle.source_product.id ||
      !bundle.products ||
      bundle.products.length === 0
    ) {
      widget.style.display = "none";
      return;
    }

    // Déduplication inter-zones (le bundle a la priorité sur les zones suivantes)
    var products = applyDedupe(bundle.products);
    if (products.length === 0) {
      widget.style.display = "none";
      return;
    }

    var labels = bundleLabels();
    var html =
      '<div class="recokit-bundle-items" style="display:flex;align-items:stretch;gap:8px;overflow-x:auto;padding:4px 2px 8px;width:100%;">';

    // Produit source : premier élément fixe (toujours dans la sélection)
    var source = bundle.source_product;
    if (source && source.id) {
      displayedProductIds[String(source.id)] = true;
      html +=
        '<label class="recokit-bundle-item recokit-bundle-source" data-recokit-price="' +
        (source.price_value != null ? source.price_value : 0) +
        '" style="display:flex;flex-direction:column;justify-content:center;flex:0 0 190px;min-height:150px;gap:6px;padding:10px;border:1px solid #e5e7eb;border-radius:10px;background:#fafafa;cursor:pointer;">' +
        '<input type="checkbox" class="recokit-bundle-check" checked data-recokit-add="' +
        escapeHtml(String(source.id)) +
        '" onchange="window.__recokitUpdateBundleSubtotal(this)" style="width:18px;height:18px;accent-color:#111;flex-shrink:0;">' +
        (source.image
          ? '<img src="' +
            source.image +
            '" alt="' +
            escapeHtml(source.name) +
            '" loading="lazy" style="width:120px;height:120px;object-fit:contain;border-radius:8px;">'
          : "") +
        '<div style="flex:1;min-width:0;">' +
        '<a href="' +
        (source.url || "#") +
        '" data-recokit-id="' +
        escapeHtml(String(source.id)) +
        '" style="font-size:13px;font-weight:600;color:inherit;text-decoration:none;">' +
        escapeHtml(source.name) +
        "</a>" +
        '<span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:.04em;color:#6b7280;">' +
        labels.current +
        "</span>" +
        "</div>" +
        '<span class="recokit-bundle-price" style="font-size:13px;font-weight:600;">' +
        escapeHtml(source.price || "") +
        "</span>" +
        "</label>";
    }

    // Produits du bundle : cochables (cochés par défaut)
    products.forEach(function (rec) {
      html +=
        '<span aria-hidden="true" style="display:flex;align-items:center;justify-content:center;flex:0 0 24px;font-size:24px;color:#9ca3af;font-weight:400;">+</span>' +
        '<label class="recokit-bundle-item" data-recokit-price="' +
        (rec.price_value != null ? rec.price_value : 0) +
        '" style="display:flex;flex-direction:column;justify-content:center;flex:0 0 190px;min-height:150px;gap:6px;padding:10px;border:1px solid #e5e7eb;border-radius:10px;background:#fff;cursor:pointer;">' +
        '<input type="checkbox" class="recokit-bundle-check" checked data-recokit-add="' +
        escapeHtml(String(rec.id)) +
        '" onchange="window.__recokitUpdateBundleSubtotal(this)" style="width:18px;height:18px;accent-color:#111;flex-shrink:0;">' +
        (rec.image
          ? '<img src="' +
            rec.image +
            '" alt="' +
            escapeHtml(rec.name) +
            '" loading="lazy" style="width:120px;height:120px;object-fit:contain;border-radius:8px;">'
          : "") +
        '<div style="flex:1;min-width:0;">' +
        '<a href="' +
        (rec.url || "#") +
        '" data-recokit-id="' +
        escapeHtml(String(rec.id)) +
        '" style="font-size:13px;font-weight:600;color:inherit;text-decoration:none;">' +
        escapeHtml(rec.name) +
        "</a>" +
        (rec.reason_buyer
          ? '<span style="display:block;font-size:10px;font-style:italic;color:#4f46e5;">' +
            escapeHtml(rec.reason_buyer) +
            "</span>"
          : "") +
        "</div>" +
        '<span class="recokit-bundle-price" style="font-size:13px;font-weight:600;">' +
        escapeHtml(rec.price || "") +
        "</span>" +
        "</label>";
    });

    html += "</div>";

    // Sous-total dynamique + bouton « Tout ajouter »
    html +=
      '<div class="recokit-bundle-footer" style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:12px;padding-top:12px;border-top:1px solid #e5e7eb;">' +
      '<div style="font-size:13px;"><span style="color:#6b7280;">' +
      labels.subtotal +
      "\u00a0: </span><strong class=\"recokit-bundle-subtotal\" style=\"font-size:16px;\"></strong></div>";
    if (displaySettings.enable_add_to_cart !== false) {
      html +=
        '<button type="button" class="recokit-atc recokit-bundle-add-all">' +
        labels.addAll +
        "</button>";
    }
    html += "</div>";

    content.innerHTML = html;
    widget.style.display = "";

    // Bouton « Tout ajouter au panier » (les checkboxes portent data-recokit-add)
    var addAllBtn = content.querySelector(".recokit-bundle-add-all");
    if (addAllBtn) {
      addAllBtn.addEventListener("click", function () {
        addBundleToCart(addAllBtn);
      });
    }

    updateBundleSubtotal();
  }

  function updateBundleSubtotal() {
    var widgets = document.querySelectorAll("#recokit-bundle-widget");
    for (var w = 0; w < widgets.length; w++) {
      var zone = widgets[w];
      var total = 0;
      var sampleEl = zone.querySelector(".recokit-bundle-price");
      var items = zone.querySelectorAll(".recokit-bundle-item");
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var check = item.querySelector(".recokit-bundle-check");
        if (!check || check.checked) {
          total += parseFloat(item.getAttribute("data-recokit-price") || "0") || 0;
        }
      }
      var subtotalEl = zone.querySelector(".recokit-bundle-subtotal");
      if (subtotalEl) {
        subtotalEl.textContent = formatMoney(
          sampleEl ? sampleEl.textContent : null,
          total,
        );
      }
    }
  }

  // Exposé global pour les attributs onchange inline du bundle
  window.__recokitUpdateBundleSubtotal = function () {
    updateBundleSubtotal();
  };

  function addBundleToCart(btn) {
    if (btn.disabled) return;
    var labels = bundleLabels();
    var zone = btn.closest("#recokit-bundle-widget");
    if (!zone) return;

    var checks = zone.querySelectorAll('.recokit-bundle-check:checked');
    if (!checks.length) return;

    btn.disabled = true;
    btn.textContent = labels.adding;

    var cartUrl = "";
    if (typeof prestashop !== "undefined" && prestashop.urls && prestashop.urls.pages && prestashop.urls.pages.cart) {
      cartUrl = prestashop.urls.pages.cart;
    } else if (typeof prestashop !== "undefined" && prestashop.urls && prestashop.urls.base_url) {
      cartUrl = prestashop.urls.base_url + "index.php?controller=cart";
    } else {
      cartUrl = window.location.origin + "/index.php?controller=cart";
    }
    var token = getCartToken();

    var queue = Array.prototype.slice.call(checks);
    var completed = 0;
    var failed = false;
    var lastResponse = null;
    var lastProductId = null;

    function next() {
      if (failed) return;
      if (completed === queue.length) {
        btn.textContent = labels.added;
        btn.classList.add("is-added");
        showCartToast(labels.added);
        if (typeof prestashop !== "undefined" && typeof prestashop.emit === "function") {
          try {
            prestashop.emit("updateCart", {
              reason: {
                idProduct: lastProductId,
                idProductAttribute: 0,
                linkAction: "add-to-cart"
              },
              resp: lastResponse || {}
            });
          } catch (err) {}
        }
        refreshCartWidgets(lastProductId ? String(lastProductId) : null);
        setTimeout(function () {
          btn.disabled = false;
          btn.textContent = labels.addAll;
          btn.classList.remove("is-added");
        }, 2500);
        return;
      }

      var check = queue[completed++];
      var productId = check.getAttribute("data-recokit-add");
      if (!productId) {
        next();
        return;
      }

      var formData = new FormData();
      formData.append("ajax", "1");
      formData.append("action", "update");
      formData.append("add", "1");
      formData.append("id_product", String(productId));
      formData.append("id_product_attribute", "0");
      formData.append("qty", "1");
      if (token) formData.append("token", token);

      var xhr = new XMLHttpRequest();
      xhr.open("POST", cartUrl, true);
      xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
      xhr.onload = function () {
        var ok = false;
        try {
          var resp = JSON.parse(xhr.responseText);
          ok = (xhr.status >= 200 && xhr.status < 300) && (!resp.hasError && (!resp.errors || resp.errors.length === 0));
        } catch (e) {
          ok = (xhr.status >= 200 && xhr.status < 300);
        }
        if (!ok) {
          console.warn("[RecoKit] Bundle add failed for product", productId, xhr.status, xhr.responseText);
          failed = true;
          btn.textContent = labels.error;
          btn.classList.add("is-error");
          setTimeout(function () {
            btn.disabled = false;
            btn.textContent = labels.addAll;
            btn.classList.remove("is-error");
          }, 2500);
          return;
        }
        lastResponse = resp || {};
        lastProductId = productId;
        next();
      };
      xhr.onerror = function () {
        failed = true;
        btn.textContent = labels.error;
        btn.classList.add("is-error");
        setTimeout(function () {
          btn.disabled = false;
          btn.textContent = labels.addAll;
          btn.classList.remove("is-error");
        }, 2500);
      };
      xhr.send(formData);
    }

    next();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Tracking
  // ────────────────────────────────────────────────────────────────────────

  function trackClick(recommendedProductId) {
    // Tracking léger : image beacon (ne bloque pas la navigation)
    var img = new Image();
    img.src =
      API_BASE +
      "/track/click" +
      "?session=" +
      encodeURIComponent(ensureSession()) +
      "&source=" +
      encodeURIComponent(PRODUCT_ID) +
      "&target=" +
      encodeURIComponent(recommendedProductId) +
      "&_=" +
      Date.now();
  }

  // ────────────────────────────────────────────────────────────────────────
  //  Initialisation
  // ────────────────────────────────────────────────────────────────────────

  function currentCartProductIds() {
    var domIds = [];
    document
      .querySelectorAll(
        ".cart-item[data-id-product], " +
          ".cart-overview [data-id-product], " +
          ".cart-products [data-id-product], " +
          ".js-cart-line-product-quantity[data-product-id]",
      )
      .forEach(function (el) {
        var id =
          el.getAttribute("data-id-product") ||
          el.getAttribute("data-product-id");
        if (id && domIds.indexOf(String(id)) === -1) domIds.push(String(id));
      });
    return domIds.length ? domIds : CART_PRODUCT_IDS.slice();
  }

  // Endpoint API propre à chaque zone panier : la page panier n'expose
  // jamais un archétype déjà présent dans le panier (pas de seconde pompe à
  // côté de la pompe choisie) ; la popup d'ajout l'admet en dernier recours
  // pour combler la grille.
  function cartZoneEndpoint(zoneType) {
    return zoneType === "cart_page"
      ? "/cart-page-recommendations"
      : "/cart-recommendations";
  }

  function cartZoneFetchLimit(zoneType) {
    var value = parseInt(zoneLimit(zoneType), 10);
    if (isNaN(value) || value < 1) value = parseInt(LIMIT, 10) || 4;
    return Math.min(value, 20);
  }

  function fetchCartRecommendations(productIds, zoneType, callback) {
    if (!productIds.length) return callback(null, []);
    var endpoint = cartZoneEndpoint(zoneType);
    function send(url, onStatus) {
      var xhr = new XMLHttpRequest();
      xhr.open(
        "GET",
        API_BASE +
          url +
          "?product_ids=" +
          encodeURIComponent(productIds.join(",")) +
          "&limit=" +
          cartZoneFetchLimit(zoneType),
        true,
      );
      xhr.setRequestHeader("X-Api-Key", API_KEY);
      // The cart endpoint may wake a tenant DB on the first request.
      xhr.timeout = API_REQUEST_TIMEOUT_MS;
      xhr.onload = function () {
        if (xhr.status < 200 || xhr.status >= 300) {
          return onStatus(xhr.status);
        }
        try {
          // Payload complet : recommendations + display_settings (zones panier).
          callback(null, JSON.parse(xhr.responseText));
        } catch (e) {
          callback(e, []);
        }
      };
      xhr.onerror = function () { callback(new Error("Network error"), []); };
      xhr.ontimeout = function () { callback(new Error("Timeout"), []); };
      xhr.send();
    }
    send(endpoint, function (status) {
      if (status === 404 && endpoint !== "/cart-recommendations") {
        // Backend plus ancien sans l'endpoint dédié à la zone : retomber sur
        // l'endpoint historique plutôt que de laisser la zone vide.
        send("/cart-recommendations", function (fallbackStatus) {
          callback(new Error("HTTP " + fallbackStatus), []);
        });
        return;
      }
      callback(new Error("HTTP " + status), []);
    });
  }

  function getCartContainers() {
    var containers = Array.prototype.slice.call(
      document.querySelectorAll(".recokit-cart-recommendations"),
    );
    if (!containers.length) {
      // Variantes courantes du modal blockcart selon les thèmes (classic,
      // classic-rocket, forks) : id ou classe, modal bootstrap ou pas.
      var modalHost = document.querySelector(
        "#blockcart-modal .cart-content, #blockcart-modal .modal-body, " +
          ".blockcart-modal .modal-body, #blockcart-modal, .blockcart-modal",
      );
      if (modalHost) {
        var cartTitle =
          (document.documentElement.lang || "fr").slice(0, 2).toLowerCase() ===
          "fr"
            ? "Complétez votre panier"
            : "Complete your order";
        var container = document.createElement("section");
        container.className =
          "recokit-cart-recommendations recokit-cart-recommendations--modal";
        container.style.display = "none";
        container.innerHTML =
          '<div class="recokit-widget recokit-cart-widget">' +
          '<h3 class="recokit-widget__title">' +
          cartTitle +
          "</h3>" +
          '<div class="recokit-widget__grid" role="list" ' +
          'aria-live="polite"></div>' +
          "</div>";
        modalHost.appendChild(container);
        containers.push(container);
      }
    }
    return containers;
  }

  // Type de zone d'affichage d'un conteneur panier (page panier vs popup
  // d'ajout) — chaque zone a ses propres limite et mise en page (dashboard).
  function cartZoneTypeFor(container) {
    return container && container.classList.contains("recokit-cart-recommendations--modal")
      ? "cart_modal"
      : "cart_page";
  }

  function cartZoneEnabled(zoneType) {
    var zone = zoneConfig(zoneType);
    // Pas de config servie (ancienne API) : comportement historique = affiché.
    return !zone || zone.enabled !== false;
  }

  function refreshCartWidgets(extraProductId) {
    if (displaySettings.cart_modal_recommendations === false) {
      document.querySelectorAll(".recokit-cart-recommendations--modal").forEach(function (el) {
        el.style.display = "none";
      });
      return;
    }
    if (
      extraProductId &&
      CART_PRODUCT_IDS.indexOf(String(extraProductId)) === -1
    ) {
      CART_PRODUCT_IDS.push(String(extraProductId));
    }
    var containers = getCartContainers();
    if (!containers.length) return;
    var productIds = currentCartProductIds();
    if (!productIds.length) {
      // Aucun ID produit disponible (panier vide côté serveur au chargement
      // + événement sans reason.idProduct) : l'API ne sera pas appelée.
      console.warn(
        "[RecoKit] Aucun ID produit panier disponible — appel API recommandations annulé",
      );
      return;
    }
    // Grouper les conteneurs par zone : chaque zone appelle son endpoint
    // dédié (page panier = archétypes exclus, popup = fallback admis).
    var groups = {};
    containers.forEach(function (container) {
      var zoneType = cartZoneTypeFor(container);
      if (!groups[zoneType]) groups[zoneType] = [];
      groups[zoneType].push(container);
    });
    Object.keys(groups).forEach(function (zoneType) {
      fetchCartRecommendations(
        productIds,
        zoneType,
        function (err, payload) {
          // L'API renvoie {recommendations, display_settings} ; tolérer aussi
          // un tableau nu (anciennes réponses) par sécurité.
          var recommendations = Array.isArray(payload)
            ? payload
            : payload && Array.isArray(payload.recommendations)
              ? payload.recommendations
              : [];
          // Les réglages des zones panier (limite, mise en page) voyagent avec
          // la réponse : les fusionner avant le rendu, zone par conteneur.
          if (payload && payload.display_settings && typeof payload.display_settings === "object") {
            displaySettings = Object.assign(displaySettings, payload.display_settings);
          }
          if (err) {
            console.warn(
              "[RecoKit] Erreur recommandations panier (" + zoneType + "):",
              err.message || err,
            );
          }
          groups[zoneType].forEach(function (container) {
            if (!cartZoneEnabled(zoneType)) {
              container.style.display = "none";
              return;
            }
            var grid = container.querySelector(".recokit-widget__grid");
            var zoneRecommendations = recommendations.slice(0, zoneLimit(zoneType));
            if (!grid || !zoneRecommendations.length) {
              // Garder un bloc déjà rempli (rendu du template panier ou
              // rafraîchissement précédent) quand le fetch échoue ou renvoie
              // vide : le masquer effacerait des produits visibles.
              if (!grid || !grid.children.length) container.style.display = "none";
              return;
            }
            console.info("[RecoKit] Recommandations panier reçues (" + zoneType + "):", zoneRecommendations.length);
            grid.innerHTML = zoneRecommendations.map(function (rec) {
              return renderCard(rec);
            }).join("");
            // Some classic-theme rules hide hook sections by default. The API
            // response is authoritative once products are available.
            container.style.setProperty("display", "block", "important");
            if (!grid.getAttribute("data-recokit-cart-bound")) {
              grid.setAttribute("data-recokit-cart-bound", "1");
              enhanceWidget(
                container.querySelector(".recokit-widget") || container,
                grid,
                zoneType,
              );
            }
          });
        },
      );
    });
  }

  // Un conteneur panier a besoin d'être rendu s'il n'existe pas encore ou
  // si sa grille est vide. Sert à arrêter les retries dès que le rendu a eu lieu.
  function cartWidgetNeedsRender() {
    var containers = document.querySelectorAll(".recokit-cart-recommendations");
    if (!containers.length) return true;
    for (var i = 0; i < containers.length; i++) {
      var grid = containers[i].querySelector(".recokit-widget__grid");
      if (!grid || !grid.children.length) return true;
    }
    return false;
  }

  // Les thèmes (classic inclus) injectent souvent #blockcart-modal
  // asynchronement après l'événement updateCart : un seul essai à +300ms
  // rate l'injection et n'appelle jamais l'API. On retente tant que le
  // conteneur modal n'est pas rendu.
  function refreshCartWidgetsWithRetry(extraProductId) {
    refreshCartWidgets(extraProductId);
    [500, 1200, 2500].forEach(function (delay) {
      setTimeout(function () {
        if (cartWidgetNeedsRender()) refreshCartWidgets(extraProductId);
      }, delay);
    });
  }

  function initCartWidgets() {
    refreshCartWidgets();
    if (typeof prestashop !== "undefined" && prestashop.on) {
      ["updateCart", "updatedCart"].forEach(function (eventName) {
        prestashop.on(eventName, function (event) {
          var reason = event && event.reason ? event.reason : {};
          var addedId =
            reason.idProduct || reason.id_product || null;
          refreshCartWidgetsWithRetry(addedId);
        });
      });
    }
    new MutationObserver(function () {
      if (
        document.querySelector(
          ".recokit-cart-recommendations:not([data-recokit-seen])",
        )
      ) {
        document
          .querySelectorAll(".recokit-cart-recommendations")
          .forEach(function (el) {
            el.setAttribute("data-recokit-seen", "1");
          });
        refreshCartWidgets();
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  function init() {
    if (!API_KEY) return;
    adoptThemeButtonStyles();
    initCartWidgets();
    // Cart pages expose recokitProductId="0"; they only need cart widgets,
    // not a useless product-page BFF request for product zero.
    if (!PRODUCT_ID || String(PRODUCT_ID) === "0") return;

    var sessionId = hasConsent() ? ensureSession() : null;

    // --- Recommandations (widget principal = zones complementary/intention) ---
    // Montrer le skeleton pendant le chargement
    var widget = document.getElementById("recokit-widget");
    if (widget) {
      widget.style.display = "";
    }

    fetchWidgetZones(PRODUCT_ID, sessionId, function (err, payload) {
        if (err) {
          console.warn(
            "[RecoKit] Erreur chargement recommandations:",
            err.message,
          );
          if (widget) widget.style.display = "none";
          return;
        }
        if (payload && payload.display_settings) {
          displaySettings = Object.assign(displaySettings, payload.display_settings);
        }
        renderBffZones(payload || { zones: [] });
      },
    );
  }

  // Zones secondaires. La réponse principale transporte la configuration
  // zones/dedupe (display_settings) : on charge ensuite les données des zones
  // activées séquentiellement dans l'ordre configuré, afin que l'API puisse
  // exclure les produits déjà exposés avant son pDPP live.
  function initZonesAfterMain(mainPayload) {
    var zoneData = {
      bundle: null,
      similar: [],
      comparator: [],
    };

    var order = (displaySettings.zones || []).filter(function (z) {
      return z && z.enabled !== false && ["bundle", "similar", "comparator"].indexOf(z.type) >= 0;
    }).map(function (z) { return z.type; });
    if (!order.length) order = ["bundle", "similar", "comparator"];
    var shown = [String(PRODUCT_ID)];
    function next(index) {
      if (index >= order.length) { renderAllZones(mainPayload, zoneData); return; }
      var type = order[index];
      if (!isZoneEnabled(type)) { next(index + 1); return; }
      if (type === "bundle") {
        fetchBundle(PRODUCT_ID, zoneLimit(type), function (err, bundle) {
          if (!err && bundle) { zoneData.bundle = bundle; (bundle.products || []).forEach(function (p) { shown.push(String(p.id)); }); }
          next(index + 1);
        });
      } else if (type === "similar") {
        fetchSimilar(PRODUCT_ID, 50, shown, function (err, recs) {
          if (!err) { zoneData.similar = recs || []; zoneData.similar.forEach(function (p) { shown.push(String(p.id)); }); }
          next(index + 1);
        });
      } else {
        fetchComparator(PRODUCT_ID, 50, shown, function (err, recs) {
          if (!err) { zoneData.comparator = recs || []; zoneData.comparator.forEach(function (p) { shown.push(String(p.id)); }); }
          next(index + 1);
        });
      }
    }
    next(0);
  }

  function renderIntentionsWidget(intentions) {
    var widget = document.getElementById("recokit-widget");
    var skeleton = widget
      ? widget.querySelector(".recokit-widget__skeleton")
      : null;
    var grid = widget ? widget.querySelector(".recokit-widget__grid") : null;
    if (!widget || !grid) return;

    var html = "";
    (intentions || []).forEach(function (intention) {
      var recommendations = takeUnique(
        intention.recommendations || [],
        zoneLimit("complementary"),
      );
      if (!recommendations.length) return;
      html +=
        '<section class="recokit-intention-group" style="grid-column:1/-1;">' +
        '<h3 style="margin:0 0 12px;font-size:18px;">' +
        escapeHtml(
          intention.name || intention.label || intention.intention || "",
        ) +
        "</h3>" +
        '<div class="recokit-widget__grid">';
      recommendations.forEach(function (rec) {
        html += renderCard(rec);
      });
      html += "</div></section>";
    });
    if (skeleton) skeleton.style.display = "none";
    grid.innerHTML = html;
    // Chaque groupe d'intention embarque sa propre grille : leur appliquer
    // aussi le nombre de colonnes configuré (mode grille uniquement, hérité
    // de la zone « complémentaire »).
    Array.prototype.forEach.call(
      grid.querySelectorAll(".recokit-widget__grid"),
      function (nestedGrid) {
        applyGridLayout(nestedGrid, zoneGridColumns("complementary"));
      },
    );
    widget.style.display = html ? "" : "none";
  }

  function renderAllZones(mainPayload, zoneData) {
    var mainRecommendations = mainPayload.recommendations || [];
    var intentions = mainPayload.intentions || [];
    displayedProductIds = {};
    displayedProductIds[String(PRODUCT_ID)] = true; // le produit source n'est jamais recommandé

    // Déduplication + rendu dans l'ordre configuré (défaut : bundle,
    // complementary, intention, similar, comparator).
    var order = displaySettings.zones
      ? displaySettings.zones
          .filter(function (z) {
            return z && z.enabled && z.type !== "intention";
          })
          .map(function (z) {
            return z.type;
          })
      : ["bundle", "complementary", "similar", "comparator"];

    var bundleRendered = false;
    var mainRendered = false;
    var similarRendered = false;
    var comparatorRendered = false;

    order.forEach(function (type) {
      if (type === "bundle" && !bundleRendered) {
        bundleRendered = true;
        renderBundleWidget(zoneData.bundle); // applique applyDedupe en interne
      } else if (type === "complementary" && !mainRendered) {
        mainRendered = true;
        if (displaySettings.personalization_enabled && intentions.length) {
          renderIntentionsWidget(intentions);
        } else {
          renderWidget(takeUnique(mainRecommendations, zoneLimit("complementary")));
        }
      } else if (type === "similar" && !similarRendered) {
        similarRendered = true;
        renderSimilarWidget(applyDedupe(zoneData.similar));
      } else if (type === "comparator" && !comparatorRendered) {
        comparatorRendered = true;
        renderComparatorWidget(applyDedupe(zoneData.comparator));
      }
    });

    // Compatibilité avec les anciennes configurations qui n'avaient pas de
    // zone ``complementary`` explicite : le pool principal reste la zone
    // « Vous aimerez aussi » au lieu d'être silencieusement masqué.
    if (!mainRendered && mainRecommendations.length) {
      mainRendered = true;
      if (displaySettings.personalization_enabled && intentions.length) {
        renderIntentionsWidget(intentions);
      } else {
        renderWidget(takeUnique(mainRecommendations, zoneLimit("complementary")));
      }
    }

    // Masquer les zones non rendues (désactivées ou vides)
    if (!bundleRendered) {
      var bw = document.getElementById("recokit-bundle-widget");
      if (bw) bw.style.display = "none";
    }
    if (!mainRendered) {
      var mw = document.getElementById("recokit-widget");
      if (mw) mw.style.display = "none";
    }
    if (!similarRendered) {
      var sw = document.getElementById("recokit-similar-widget");
      if (sw) sw.style.display = "none";
    }
    if (!comparatorRendered) {
      var cw = document.getElementById("recokit-comparator-widget");
      if (cw) cw.style.display = "none";
    }

    // --- Ordre des zones : réordonne les sections selon la config marchand ---
    reorderZoneSections();
  }

  function renderBffZones(payload) {
    displayedProductIds = {};
    displayedProductIds[String(PRODUCT_ID)] = true;
    var rendered = { bundle: false, complementary: false, similar: false, comparator: false };
    (payload.zones || []).forEach(function (zone) {
      var products = zone.products || [];
      if (zone.type === "bundle") {
        rendered.bundle = true;
        renderBundleWidget({
          products: products,
          source_product: zone.source_product,
          name: zone.name,
          explanation: zone.explanation,
          reason_buyer: zone.reason_buyer
        });
      }
      else if (zone.type === "complementary") {
        rendered.complementary = true;
        if (displaySettings.personalization_enabled && Array.isArray(zone.intentions) && zone.intentions.length) {
          renderIntentionsWidget(zone.intentions);
        } else {
          renderWidget(products);
        }
      }
      else if (zone.type === "similar") { rendered.similar = true; renderSimilarWidget(products); }
      else if (zone.type === "comparator") { rendered.comparator = true; renderComparatorWidget(products); }
    });
    [["recokit-bundle-widget", rendered.bundle], ["recokit-widget", rendered.complementary],
      ["recokit-similar-widget", rendered.similar], ["recokit-comparator-widget", rendered.comparator]]
      .forEach(function (entry) {
        var el = document.getElementById(entry[0]);
        if (el && !entry[1]) el.style.display = "none";
      });
    reorderZoneSections();
  }

  function reorderZoneSections() {
    if (!displaySettings.zones) return; // pas de config → ordre historique du TPL

    var main = document.getElementById("recokit-widget");
    if (!main) return;
    var parent = main.parentNode;

    var sectionIds = {
      bundle: "recokit-bundle-widget",
      complementary: "recokit-widget",
      intention: "recokit-widget",
      similar: "recokit-similar-widget",
      comparator: "recokit-comparator-widget",
    };

    // Point d'insertion : l'élément qui suit la première section RecoKit
    // du thème (les zones se réordonnent entre elles sans bouger le hook).
    var recokitSections = Array.prototype.filter.call(
      parent.children,
      function (el) {
        return (
          el.id === "recokit-bundle-widget" ||
          el.id === "recokit-widget" ||
          el.id === "recokit-similar-widget" ||
          el.id === "recokit-comparator-widget"
        );
      },
    );
    if (recokitSections.length < 2) return;
    var insertionPoint = recokitSections[0].nextSibling;

    var seenContainers = {};
    displaySettings.zones.forEach(function (zone) {
      if (!zone || !zone.type) return;
      var id = sectionIds[zone.type];
      if (!id || seenContainers[id]) return;
      seenContainers[id] = true;
      var el = document.getElementById(id);
      if (!el) return;
      parent.insertBefore(el, insertionPoint);
    });
  }

  // Lancement après le chargement du DOM
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
