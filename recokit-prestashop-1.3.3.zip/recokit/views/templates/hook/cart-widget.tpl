{* Recommandations complémentaires panier — page ou modal add-to-cart. *}
<script>
window.recokitApiKey = window.recokitApiKey || {$recokit_api_key_json nofilter};
window.recokitApiBase = window.recokitApiBase || {$recokit_api_base_json nofilter};
window.recokitCartProductIds = window.recokitCartProductIds || {$recokit_cart_product_ids_json nofilter};
</script>
<link rel="stylesheet" href="{$recokit_widget_css|escape:'htmlall':'UTF-8'}">
<script src="{$recokit_widget_js|escape:'htmlall':'UTF-8'}" defer></script>
<section class="recokit-cart-recommendations recokit-cart-recommendations--{$recokit_cart_placement|escape:'htmlall':'UTF-8'}" style="display:none;">
    <div class="recokit-widget recokit-cart-widget">
        <h3 class="recokit-widget__title">{l s='Complétez votre panier' mod='recokit'}</h3>
        <div class="recokit-widget__grid" role="list" aria-live="polite"></div>
    </div>
</section>
