{*
 * RecoKit Widget — Template Smarty PrestaShop
 * EPIC-PS-03 / US-PS-03.2
 *
 * Ce template injecte les conteneurs HTML des zones du widget.
 * Le contenu est rempli de façon asynchrone par widget.js, dans l'ordre
 * configuré dans le dashboard (onglet « Apparence » — zones & ordre).
 * Les zones désactivées par le marchand sont masquées par le JS.
 *}

{* Zone « Bundle 1-clic » — widget composite « Complétez votre équipement »
   avec cases à cocher et sous-total dynamique (rempli par fetchBundle). *}
<section id="recokit-bundle-widget" class="recokit-widget recokit-bundle-widget" aria-label="{l s='Complétez votre équipement' mod='recokit'}" style="display:none;">
    <h3 class="recokit-widget__title">{l s='Complétez votre équipement' mod='recokit'}</h3>
    <div class="recokit-widget__skeleton" aria-hidden="true">
        {for $i=1 to $recokit_limit}
        <div class="recokit-skeleton-card">
            <div class="recokit-skeleton-img"></div>
            <div class="recokit-skeleton-text"></div>
            <div class="recokit-skeleton-price"></div>
        </div>
        {/for}
    </div>
    {* Contenu composite — rempli par JS *}
    <div class="recokit-widget__grid recokit-bundle-widget__content" role="list" aria-live="polite"></div>
</section>

<section id="recokit-widget" class="recokit-widget" aria-label="{l s='Vous aimerez aussi' mod='recokit'}" style="display:none;">
    <h3 class="recokit-widget__title">{l s='Vous aimerez aussi' mod='recokit'}</h3>

    {* Skeleton loader affiché pendant le chargement AJAX *}
    <div class="recokit-widget__skeleton" aria-hidden="true">
        {for $i=1 to $recokit_limit}
        <div class="recokit-skeleton-card">
            <div class="recokit-skeleton-img"></div>
            <div class="recokit-skeleton-text"></div>
            <div class="recokit-skeleton-price"></div>
        </div>
        {/for}
    </div>

    {* Grille produits — remplie par JS *}
    <div class="recokit-widget__grid" role="list" aria-live="polite"></div>
</section>

{* Zone « Produits similaires » — remplie asynchronement par widget.js (fetchSimilar) *}
<section id="recokit-similar-widget" class="recokit-widget recokit-similar-widget" aria-label="{l s='Produits similaires' mod='recokit'}" style="display:none;">
    <h3 class="recokit-widget__title">{l s='Produits similaires' mod='recokit'}</h3>

    {* Skeleton loader affiché pendant le chargement AJAX *}
    <div class="recokit-widget__skeleton" aria-hidden="true">
        {for $i=1 to $recokit_limit}
        <div class="recokit-skeleton-card">
            <div class="recokit-skeleton-img"></div>
            <div class="recokit-skeleton-text"></div>
            <div class="recokit-skeleton-price"></div>
        </div>
        {/for}
    </div>

    {* Grille produits — remplie par JS *}
    <div class="recokit-widget__grid" role="list" aria-live="polite"></div>
</section>

{* Zone « Comparateur » (Pro) — remplie asynchronement par widget.js (fetchComparator).
   Masquée silencieusement si l'offre n'est pas Pro (HTTP 403). *}
<section id="recokit-comparator-widget" class="recokit-widget recokit-comparator-widget" aria-label="{l s='Comparer les produits' mod='recokit'}" style="display:none;">
    <h3 class="recokit-widget__title">{l s='Comparer à des produits similaires' mod='recokit'}</h3>

    {* Skeleton loader affiché pendant le chargement AJAX *}
    <div class="recokit-widget__skeleton" aria-hidden="true">
        {for $i=1 to $recokit_limit}
        <div class="recokit-skeleton-card">
            <div class="recokit-skeleton-img"></div>
            <div class="recokit-skeleton-text"></div>
            <div class="recokit-skeleton-price"></div>
        </div>
        {/for}
    </div>

    {* Grille produits — remplie par JS *}
    <div class="recokit-widget__grid recokit-comparator-widget__grid" role="list" aria-live="polite"></div>
</section>
