<?php
/**
 * RecoKit — Module PrestaShop
 *
 * Intègre le moteur de recommandation RecoKit dans une boutique PrestaShop.
 * Compatible PrestaShop 1.7.x et 8.x / PHP 7.4+
 *
 * EPIC-PS-01 : Module de base (scaffold, config, sync manuelle)
 * EPIC-PS-03 : Widget JS de recommandations
 * EPIC-PS-04 : Hooks de synchronisation automatique
 *
 * @author  RecoKit
 * @version 1.3.3
 * @license MIT
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Recokit extends Module
{
    const API_BASE_URL    = 'https://api.recokit.fr/api/prestashop';
    const COOKIE_NAME     = '_recokit_session';
    const COOKIE_LIFETIME = 2592000; // 30 jours

    public function __construct()
    {
        $this->name          = 'recokit';
        $this->tab           = 'advertising_marketing';
        $this->version       = '1.3.3';
        $this->author        = 'RecoKit';
        $this->need_instance = 0;
        $this->bootstrap     = true;

        parent::__construct();

        $this->displayName = $this->l('RecoKit — Recommandations IA');
        $this->description = $this->l(
            'Affiche des recommandations produits personnalisées générées par IA sur vos fiches produits.'
        );
        $this->confirmUninstall = $this->l('Êtes-vous sûr de vouloir désinstaller RecoKit ?');
        $this->ps_versions_compliancy = ['min' => '1.7.0', 'max' => _PS_VERSION_];
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Installation / Désinstallation
    // ─────────────────────────────────────────────────────────────────────────

    public function install()
    {
        if (!parent::install()
            || !$this->registerHook('actionProductSave')
            || !$this->registerHook('actionUpdateQuantity')
            || !$this->registerHook('actionProductDelete')
            || !$this->registerHook('actionOrderStatusUpdate')
            || !$this->registerHook('displayFooterProduct')
            || !$this->registerHook('displayProductAdditionalInfo')
            || !$this->registerHook('displayShoppingCartFooter')
            || !$this->registerHook('displayCartModalFooter')
            || !$this->registerHook('actionFrontControllerSetMedia')
        ) {
            return false;
        }

        // ✨ Auto-enregistrement : création du compte RecoKit + génération clé API
        $this->_autoRegister();

        return true;
    }

    public function uninstall()
    {
        // Preserve the shop identity and settings across a module reinstall.
        // Credentials are removed only through the explicit Disconnect action.
        return parent::uninstall();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Auto-enregistrement
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Auto-enregistrement à l'installation du module.
     * Appelle POST /api/prestashop/register — crée le compte et stocke la clé API
     * automatiquement. Le marchand n'a rien à faire.
     */
    private function _autoRegister()
    {
        $shopUrl   = Tools::getShopDomainSsl(true);
        $shopEmail = $this->_getRegistrationEmail();
        $shopName  = Configuration::get('PS_SHOP_NAME');

        $payload = [
            'shop_url'   => $shopUrl,
            'shop_email' => $shopEmail,
            'shop_name'  => $shopName,
            'ps_version' => _PS_VERSION_,
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => self::getApiBaseUrl() . '/register',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if (in_array($httpCode, [200, 201]) && $response) {
            $data   = json_decode($response, true);
            $apiKey = $data['api_key'] ?? null;
            $integrationKey = $data['integration_api_key'] ?? null;
            if ($apiKey && $integrationKey) {
                Configuration::updateValue('RECOKIT_API_KEY', $apiKey);
                Configuration::updateValue('RECOKIT_INTEGRATION_API_KEY', $integrationKey);
                Configuration::updateValue('RECOKIT_RETAILER_ID', $data['retailer_id'] ?? '');
                Logger::addLog('[RecoKit] Compte créé automatiquement. Clé API sauvegardée.', 1);

                // Déclencher la synchronisation initiale du catalogue
                $this->syncCatalog();
                return true;
            }
            Logger::addLog('[RecoKit] Réponse d’enregistrement invalide (HTTP ' . $httpCode . ').', 2);
        } else {
            $detail = $curlError ?: ('HTTP ' . $httpCode);
            Logger::addLog(
                '[RecoKit] Auto-enregistrement impossible sur ' . self::getApiBaseUrl() . '/register : ' . $detail,
                2
            );
        }
        return false;
    }

    /**
     * Uses the same address as automatic registration so an existing account
     * can create its first password without exposing either API credential.
     */
    private function _getRegistrationEmail()
    {
        $adminUser = new Employee(1);
        return $adminUser->email ?: Configuration::get('PS_SHOP_EMAIL');
    }

    /**
     * Ask RecoKit to send the standard one-hour password setup/reset link.
     * The endpoint deliberately gives the same response for known and unknown
     * addresses, preventing account enumeration from the module page.
     */
    private function _sendPasswordSetupEmail()
    {
        $endpoint = self::getApiBaseUrl() . '/recovery-email';

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode([
                'shop_url' => Tools::getShopDomainSsl(true),
            ]),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($httpCode === 200) {
            Logger::addLog('[RecoKit] Email de création/réinitialisation du mot de passe demandé.', 1);
            return true;
        }
        Logger::addLog(
            '[RecoKit] Demande d’email de mot de passe impossible : '
                . ($curlError ?: ('HTTP ' . $httpCode)),
            2
        );
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Page de configuration (back-office)
    // ─────────────────────────────────────────────────────────────────────────

    public function getContent()
    {
        $apiKey = Configuration::get('RECOKIT_API_KEY');
        $integrationKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        $html = '';

        // Déconnexion / retour à la configuration
        if (Tools::isSubmit('submit_recokit_disconnect')) {
            Configuration::deleteByName('RECOKIT_API_KEY');
            Configuration::deleteByName('RECOKIT_INTEGRATION_API_KEY');
            Configuration::deleteByName('RECOKIT_RETAILER_ID');
            $apiKey = null;
            $html .= $this->displayConfirmation($this->l('Boutique déconnectée de RecoKit avec succès.'));
        }

        // Connexion / enregistrement automatique
        if (Tools::isSubmit('submit_recokit_autoregister')) {
            if ($this->_autoRegister()) {
                $apiKey = Configuration::get('RECOKIT_API_KEY');
                $integrationKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
                $html .= $this->displayConfirmation($this->l('Connexion réussie et clé API générée automatiquement !'));
            } else {
                $html .= $this->displayError($this->l('Erreur lors de la connexion automatique. Veuillez vérifier que l\'API RecoKit est accessible ou configurez la clé manuellement.'));
            }
        }

        // Existing auto-created accounts have no initial password. Send the
        // standard reset link to the address already stored during onboarding.
        if (Tools::isSubmit('submit_recokit_password_email')) {
            if ($this->_sendPasswordSetupEmail()) {
                $html .= $this->displayConfirmation($this->l('Si le compte existe, un email permettant de définir votre mot de passe vient d’être envoyé.'));
            } else {
                $html .= $this->displayError($this->l('Impossible de demander le lien pour le moment. Veuillez réessayer plus tard.'));
            }
        }

        // Si la clé a été sauvegardée manuellement ou via le formulaire standard
        if (Tools::isSubmit('submit_recokit_key') || Tools::isSubmit('submit_recokit')) {
            $newKey = Tools::getValue('RECOKIT_API_KEY');
            if ($newKey) {
                Configuration::updateValue('RECOKIT_API_KEY', trim($newKey));
                $apiKey = trim($newKey);
            }
            $newIntegrationKey = Tools::getValue('RECOKIT_INTEGRATION_API_KEY');
            if ($newIntegrationKey) {
                Configuration::updateValue('RECOKIT_INTEGRATION_API_KEY', trim($newIntegrationKey));
                $integrationKey = trim($newIntegrationKey);
            }
            $apiUrl = Tools::getValue('RECOKIT_API_URL');
            if ($apiUrl !== null) {
                Configuration::updateValue('RECOKIT_API_URL', trim($apiUrl));
            }
            $widgetLimit = Tools::getValue('RECOKIT_WIDGET_LIMIT');
            if ($widgetLimit !== false && $widgetLimit !== '') {
                Configuration::updateValue('RECOKIT_WIDGET_LIMIT', (int)$widgetLimit);
            }
        }

        // Audit léger : mêmes produits actifs des deux côtés (compteur + hash
        // des IDs). Une indisponibilité temporaire de l'API ne crée pas à elle
        // seule une fausse alerte.
        if ($integrationKey && !Tools::isSubmit('submit_recokit_sync')) {
            $this->_refreshCatalogMismatchFlag();
        }

        // Alerte : lot incomplet, modification massive ou catalogue déphasé.
        if (((int) Configuration::get('RECOKIT_NEEDS_RESYNC')
                || (int) Configuration::get('RECOKIT_CATALOG_MISMATCH'))
            && !Tools::isSubmit('submit_recokit_sync')) {
            $html .= '<div style="background-color:#fef3c7;border:2px solid #f59e0b;color:#92400e;padding:12px;border-radius:6px;font-weight:600;margin-bottom:16px;">'
                . '⚠️ ' . $this->l('La dernière synchronisation du catalogue est incomplète ou des produits ont été modifiés en masse. Le catalogue disponible reste utilisable, mais certains produits peuvent manquer. Merci de cliquer sur « Synchroniser le catalogue » pour compléter RecoKit.')
                . '</div>';
        }

        // Si le bouton de synchronisation manuelle est cliqué
        if (Tools::isSubmit('submit_recokit_sync')) {
            $res = $this->syncCatalog();
            if ($res['success']) {
                $html .= $this->displayConfirmation(
                    sprintf(
                        $this->l('Synchronisation réussie ! %d produits insérés, %d mis à jour, %d erreurs.'),
                        $res['inserted'],
                        $res['updated'],
                        $res['errors']
                    )
                );
            } else {
                $html .= $this->displayError($this->l('Erreur de synchronisation : ') . $res['message']);
            }
        }

        if (!$apiKey || !$integrationKey) {
            // Pas encore de clé → afficher le formulaire de saisie manuelle
            return $html . $this->_renderNoKeyPanel();
        }

        // ✨ Un seul iframe — toute la gestion RecoKit sans quitter PrestaShop
        $isoCode = isset($this->context->language->iso_code) ? $this->context->language->iso_code : 'fr';

        $backUrl = $this->context->link->getAdminLink('AdminModules', true) . '&configure=recokit';
        $embedBase = self::getBrowserApiBaseUrl(false);
        $embedUrl = $embedBase . '/embed?api_key=' . urlencode($integrationKey) . '&lang=' . urlencode($isoCode) . '&redirect_url=' . urlencode($backUrl);

        // Header bar stylisé et iframe d'administration
        $html .= '
        <div style="margin:-20px -20px 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;">
            <div style="background: linear-gradient(90deg, #1e1b4b 0%, #312e81 100%); color: white; padding: 12px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #4f46e5;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span style="font-size: 20px; font-weight: 800; letter-spacing: 0.5px; color: #818cf8;">recoKit</span>
                    <span style="background: #10b981; color: white; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;">
                        <span style="display: inline-block; width: 6px; height: 6px; background: white; border-radius: 50%;"></span>
                        ' . $this->l('Connecté') . '
                    </span>
                </div>
                <form method="post" style="margin: 0; display: flex; align-items: center; gap: 16px;">
                    <span style="font-size: 13px; color: #c7d2fe;">' . $this->l('Synchro : temps réel active') . '</span>
                    <button type="submit" name="submit_recokit_sync" style="background: #4f46e5; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 6px; transition: background 0.2s;" onmouseover="this.style.background=\'#4338ca\'" onmouseout="this.style.background=\'#4f46e5\'">
                       ' . $this->l('Synchroniser le catalogue produits') . '
                    </button>
                </form>
            </div>
            <iframe
                id="recokit-embed-frame"
                src="' . htmlspecialchars($embedUrl) . '"
                style="width:100%; height:calc(100vh - 110px); border:none; display:block; overflow:hidden;"
                allow="clipboard-write"
                title="RecoKit Dashboard"
            ></iframe>
        </div>
        <script>
        document.getElementById("recokit-embed-frame").addEventListener("load", function() {
            console.log("[RecoKit] Dashboard embed chargé.");
        });
        window.addEventListener("message", function(event) {
            if (event.data && event.data.type === "recokit-resize") {
                var iframe = document.getElementById("recokit-embed-frame");
                if (iframe && event.data.height) {
                    iframe.style.height = event.data.height + "px";
                }
            }
        });
        </script>';


        return $html;
    }

    /**
     * Affiché uniquement si l'auto-enregistrement a échoué (pas de clé).
     * Permet la saisie manuelle de la clé API.
     *
     * FIX #1 : suppression du </div> orphelin dans le formulaire manuel.
     */
    private function _renderNoKeyPanel()
    {
        $integrationKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');

        return '<div class="panel">
            <div class="panel-heading"><i class="icon-warning"></i> ' . $this->l('RecoKit — Configuration requise') . '</div>
            <div class="panel-body">
                <div class="alert alert-warning">
                    <p>' . $this->l('Bienvenue sur RecoKit ! Veuillez connecter votre boutique pour commencer.') . '</p>
                </div>

                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 20px; border-radius: 8px; margin-bottom: 24px; text-align: center;">
                    <h3 style="margin-top: 0; color: #166534; font-weight: 700; font-size: 16px;">' . $this->l('Configuration Automatique (Recommandé)') . '</h3>
                    <p style="color: #1e293b; margin-bottom: 16px;">' . $this->l('Enregistre automatiquement votre boutique sur notre serveur et active les recommandations en 1 clic.') . '</p>
                    <form method="post">
                        <button type="submit" name="submit_recokit_autoregister" class="btn btn-success" style="font-size: 14px; padding: 10px 20px; font-weight: bold;">
                            🔑 ' . $this->l('Se connecter automatiquement') . '
                        </button>
                    </form>
                </div>

                <div style="background:#eff6ff;border:1px solid #bfdbfe;padding:20px;border-radius:8px;margin-bottom:24px;text-align:center;">
                    <h3 style="margin-top:0;color:#1e3a8a;font-weight:700;font-size:16px;">' . $this->l('Boutique déjà enregistrée ?') . '</h3>
                    <p style="color:#1e293b;margin-bottom:16px;">' . $this->l('Recevez un lien sécurisé pour définir votre mot de passe et accéder aux clés de votre boutique dans RecoKit.') . '</p>
                    <form method="post">
                        <button type="submit" name="submit_recokit_password_email" class="btn btn-primary" style="font-size:14px;padding:10px 20px;font-weight:bold;">
                            ✉ ' . $this->l('Recevoir le lien par email') . '
                        </button>
                    </form>
                </div>

                <div style="border-top: 1px solid #e2e8f0; margin: 24px 0; padding-top: 20px;">
                    <h3 style="margin-top: 0; color: #475569; font-weight: 700; font-size: 14px;">' . $this->l('Configuration Manuelle / Avancée') . '</h3>
                    <form method="post">
                        <div class="form-group">
                            <label>' . $this->l('Clé publique RecoKit') . '</label>
                            <input type="text" name="RECOKIT_API_KEY" class="form-control" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" style="max-width:400px;" value="' . htmlspecialchars(Configuration::get('RECOKIT_API_KEY') ?: '') . '">
                        </div>
                        <div class="form-group">
                            <label>' . $this->l('Clé privée d’intégration RecoKit') . '</label>
                            <input type="password" name="RECOKIT_INTEGRATION_API_KEY" class="form-control" autocomplete="new-password" placeholder="' . ($integrationKey ? $this->l('Clé privée configurée — laisser vide pour la conserver') : 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx') . '" style="max-width:400px;" value="">
                            <p class="help-block">' . $this->l('Ne publiez jamais cette clé : elle autorise la synchronisation et l’administration.') . '</p>
                        </div>
                        <div class="form-group">
                            <label>' . $this->l('URL de l\'API RecoKit') . '</label>
                            <p class="help-block">' . $this->l('Laissez vide pour utiliser l\'URL de production par défaut (https://api.recokit.fr/api/prestashop).') . '</p>
                        </div>
                        <button type="submit" name="submit_recokit_key" class="btn btn-primary">' . $this->l('Enregistrer') . '</button>
                    </form>
                </div>
            </div>
        </div>';
    }

    /**
     * Panneau d'abonnement intégré avec checkout Polar en modale (sans quitter PS)
     */
    private function _renderBillingPanel()
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        $currentPlan = '';

        if ($apiKey) {
            $ping = $this->_apiCall('GET', '/ping');
            if ($ping && $ping['status'] === 'ok') {
                $currentPlan = $ping['plan'] ?? '';
            }
        }

        $plans = [
            ['key' => 'starter', 'label' => 'Starter',  'price' => '29€/mois', 'desc' => 'Jusqu\'à 500 produits'],
            ['key' => 'growth',  'label' => 'Growth',   'price' => '79€/mois', 'desc' => 'Jusqu\'à 2000 produits'],
            ['key' => 'pro',     'label' => 'Pro',       'price' => '149€/mois', 'desc' => 'Jusqu\'à 5000 produits'],
        ];

        $html = '<div class="panel" id="recokit-billing">
            <div class="panel-heading"><i class="icon-credit-card"></i> '.$this->l('Abonnement RecoKit').'</div>
            <div class="panel-body">';

        if ($currentPlan && strtolower($currentPlan) !== 'free') {
            $html .= '<div class="alert alert-success"><i class="icon-check"></i> '
                . $this->l('Abonnement actif : ').'<strong>'.htmlspecialchars($currentPlan).'</strong>'.
                ' — <a href="#" onclick="recokitOpenPortal(); return false;">'
                . $this->l('Gérer mon abonnement').'</a></div>';
        } else {
            $html .= '<p>'.$this->l('Choisissez votre plan pour activer les recommandations IA sur votre boutique.').'</p>
            <div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:16px;">';

            foreach ($plans as $plan) {
                $html .= '<div style="border:1px solid #ddd; border-radius:8px; padding:16px; flex:1; min-width:180px; text-align:center;">
                    <strong>'.$plan['label'].'</strong><br>
                    <span style="font-size:1.4em; font-weight:700; color:#2d6cdf;">'.$plan['price'].'</span><br>
                    <small style="color:#666;">'.$plan['desc'].'</small><br><br>
                    <button class="btn btn-primary btn-sm" onclick="recokitStartCheckout(\''.$plan['key'].'\')">
                        '.$this->l('S\'abonner').'</button>
                </div>';
            }

            $html .= '</div>';
        }

        $html .= '</div></div>

        <!-- Modale checkout Polar -->
        <div id="recokit-checkout-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:99999; align-items:center; justify-content:center;">
            <div style="background:#fff; border-radius:12px; width:90%; max-width:560px; height:80vh; position:relative; overflow:hidden;">
                <button onclick="recokitCloseModal()" style="position:absolute; top:12px; right:12px; background:none; border:none; font-size:20px; cursor:pointer; z-index:1;">&#x2715;</button>
                <iframe id="recokit-checkout-frame" src="" frameborder="0" style="width:100%; height:100%;"></iframe>
            </div>
        </div>

        <script>
        function recokitStartCheckout(planName) {
            var apiKey = ' . json_encode($apiKey ?: '') . ';
            if (!apiKey) {
                alert("' . $this->l('Clé API non trouvée. Veuillez réinstaller le module.') . '");
                return;
            }
            fetch("' . self::getBrowserApiBaseUrl(true) . '/checkout", {
                method: "POST",
                headers: {"Content-Type": "application/json", "X-Api-Key": apiKey},
                body: JSON.stringify({plan_name: planName, currency: "eur"})
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.checkout_url) {
                    var modal = document.getElementById("recokit-checkout-modal");
                    document.getElementById("recokit-checkout-frame").src = data.checkout_url;
                    modal.style.display = "flex";
                }
            })
            .catch(function(e) { alert("Erreur: " + e.message); });
        }

        function recokitCloseModal() {
            document.getElementById("recokit-checkout-modal").style.display = "none";
            document.getElementById("recokit-checkout-frame").src = "";
            // Rafraîchir le statut après paiement
            window.location.reload();
        }

        function recokitOpenPortal() {
            var apiKey = ' . json_encode($apiKey ?: '') . ';
            fetch("' . self::getBrowserApiBaseUrl(true) . '/billing-portal", {
                method: "POST",
                headers: {"X-Api-Key": apiKey}
            })
            .then(function(r) { return r.json(); })
            .then(function(data) { if(data.url) window.open(data.url, "_blank"); });
        }
        </script>';

        return $html;
    }

    /**
     * Panneau d'état de l'intégration (US-PS-05.2)
     */
    private function _renderStatusPanel()
    {
        $apiKey   = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        $isConnected = false;
        $planName    = '—';
        $productLimit = 0;
        $apiError = '';

        if ($apiKey) {
            $ping = $this->_apiCall('GET', '/ping');
            if ($ping && isset($ping['status']) && $ping['status'] === 'ok') {
                $isConnected  = true;
                $planName     = $ping['plan'] ?? '—';
                $productLimit = $ping['product_limit'] ?? 0;
            } else {
                $apiError = '<div style="background-color: #fee2e2; border: 2px solid #ef4444; color: #991b1b; padding: 12px; border-radius: 6px; font-weight: bold; margin-bottom: 16px; animation: blinker 2s linear infinite;">
                                🚨 ERREUR CRITIQUE : Clé API invalide ou serveur injoignable (401 Unauthorized). Les recommandations sont bloquées !
                             </div>
                             <style>@keyframes blinker { 50% { opacity: 0.6; } }</style>';
            }
        }

        $statusLabel = $isConnected
            ? '<span style="color:green">✅ Connecté</span>'
            : '<span style="color:red">❌ Non connecté</span>';

        return '<div class="panel">
            <div class="panel-heading"><i class="icon-dashboard"></i> '.$this->l('Statut de l\'intégration').'</div>
            <div class="panel-body">
                ' . $apiError . '
                <table class="table">
                    <tr><td><strong>'.$this->l('Statut API').'</strong></td><td>'.$statusLabel.'</td></tr>
                    <tr><td><strong>'.$this->l('Plan').'</strong></td><td>'.htmlspecialchars($planName).'</td></tr>
                    <tr><td><strong>'.$this->l('Limite produits').'</strong></td><td>'.htmlspecialchars($productLimit).'</td></tr>
                </table>
            </div>
        </div>';
    }



    // ─────────────────────────────────────────────────────────────────────────
    //  Synchronisation manuelle du catalogue (US-PS-01.3)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Appelée via le lien "Synchroniser le catalogue" depuis la page de config.
     * Envoi par batch de 200 produits maximum.
     */
    public function syncCatalog()
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey) {
            return ['success' => false, 'message' => 'Clé API manquante.'];
        }

        // Le marchand a relancé la synchro manuellement → effacer l'alerte
        Configuration::updateValue('RECOKIT_NEEDS_RESYNC', 0);
        Configuration::updateValue('RECOKIT_CATALOG_MISMATCH', 0);

        $inserted = 0;
        $updated  = 0;
        $errors   = 0;
        $batchSize = 200;
        $page = 0;
        $syncFailed = false;
        $failedPages = [];

        do {
            // Récupération des produits par batch
            $products = Product::getProducts(
                (int) Configuration::get('PS_LANG_DEFAULT'),
                $page * $batchSize,
                $batchSize,
                'id_product',
                'ASC'
            );

            if (empty($products)) {
                break;
            }

            $batch = [];
            foreach ($products as $product) {
                $batch[] = $this->_normalizeProduct($product);
            }

            // Upserts are idempotent: retry the exact same page rather than
            // advancing and silently leaving a 200-product hole.
            $response = null;
            $maxAttempts = 3;
            for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
                $candidate = $this->_apiCall('POST', '/products', ['products' => $batch]);
                $received = (int) ($candidate['total_received'] ?? 0);
                $batchErrors = (int) ($candidate['errors'] ?? count($batch));
                if ($candidate && $received === count($batch) && $batchErrors === 0) {
                    $response = $candidate;
                    break;
                }
                Logger::addLog(
                    '[RecoKit] Catalog page ' . $page . ' failed on attempt '
                    . $attempt . '/' . $maxAttempts,
                    2, null, 'Module', $this->id
                );
                if ($attempt < $maxAttempts) {
                    sleep(1 << ($attempt - 1));
                }
            }

            if ($response !== null) {
                $inserted += (int) ($response['inserted'] ?? 0);
                $updated  += (int) ($response['updated']  ?? 0);
            } else {
                $errors += count($batch);
                $syncFailed = true;
                $failedPages[] = $page;
                Configuration::updateValue('RECOKIT_NEEDS_RESYNC', 1);
                // A partial catalogue remains usable. Continue with later
                // pages, but keep the resync warning until every page succeeds.
            }

            $page++;
        } while (count($products) === $batchSize);

        return [
            'success'  => !$syncFailed,
            'inserted' => $inserted,
            'updated'  => $updated,
            'errors'   => $errors,
            'failed_pages' => $failedPages,
            'message' => $syncFailed
                ? $this->l('La synchronisation est incomplète. Merci de la relancer ; lots en erreur : ')
                    . implode(', ', $failedPages)
                : $this->l('Synchronisation terminée.'),
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Hooks — Synchronisation automatique (EPIC-PS-04)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US-PS-04.1 — Sync auto à la création/modification d'un produit.
     *
     * La synchro temps réel est suspendue pendant les imports CSV et les
     * opérations par lots (pour éviter timeouts et blocages), puis reprend
     * automatiquement pour les éditions unitaires. Un drapeau est posé
     * pendant les opérations par lots pour alerter le marchand qu'une
     * re-synchronisation manuelle est nécessaire.
     */
    public function hookActionProductSave($params)
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey || empty($params['id_product'])) {
            return;
        }

        // Suspendre la synchro temps réel pendant les imports CSV / lots
        if ($this->_isBulkOperation()) {
            Configuration::updateValue('RECOKIT_NEEDS_RESYNC', 1);
            return;
        }

        $product = new Product((int) $params['id_product'], false, (int) Configuration::get('PS_LANG_DEFAULT'));
        if (!Validate::isLoadedObject($product)) {
            return;
        }

        $normalized = $this->_normalizeProduct((array) $product);
        $response = $this->_apiCall(
            'POST',
            '/products',
            ['products' => [$normalized]],
            10
        );
        $confirmed = is_array($response)
            && ($response['status'] ?? '') === 'success'
            && (int) ($response['total_received'] ?? 0) === 1
            && (int) ($response['errors'] ?? 1) === 0
            && ((int) ($response['inserted'] ?? 0) + (int) ($response['updated'] ?? 0)) >= 1;
        if (!$confirmed) {
            Configuration::updateValue('RECOKIT_NEEDS_RESYNC', 1);
            Logger::addLog(
                '[RecoKit] Product ' . (int) $params['id_product']
                . ' was not acknowledged by RecoKit; a catalog resync is required.',
                3, null, 'Module', $this->id
            );
        }
    }

    /**
     * Stock changes use a dedicated PrestaShop hook and do not necessarily
     * trigger actionProductSave. Keep RecoKit's serving inventory current.
     */
    public function hookActionUpdateQuantity($params)
    {
        if (empty($params['id_product'])) {
            return;
        }
        $this->hookActionProductSave(['id_product' => (int) $params['id_product']]);
    }

    /**
     * Détecte si la requête courante est une opération en masse
     * (import CSV, webservice, mise à jour par lot, etc.).
     *
     * Trois signaux complémentaires :
     *  1. Paramètre controller/tab = AdminImport (import CSV standard)
     *  2. Classe du contrôleur de contexte = AdminImportController
     *  3. Debounce intra-requête : > 5 sauvegardes en 10 s = lot
     *
     * Les imports CSV s'exécutent dans une seule requête HTTP qui boucle
     * sur chaque ligne du fichier ; le compteur statique s'accumule donc
     * naturellement et bascule en mode « lot » après le 5ᵉ produit.
     * Les éditions unitaires sont des requêtes séparées : le compteur
     * repart de 1 à chaque fois.
     */
    private static $_bulkSaveTs    = 0;
    private static $_bulkSaveCount = 0;

    private function _isBulkOperation(): bool
    {
        // Signal 1 — import CSV standard (paramètre GET/POST)
        $controller = Tools::getValue('controller');
        if (!$controller) {
            $controller = Tools::getValue('tab');
        }
        if ($controller === 'AdminImport') {
            return true;
        }

        // Signal 2 — instance du contrôleur de contexte (PS 1.7+ / 8.x)
        $ctxController = isset(Context::getContext()->controller)
            ? Context::getContext()->controller
            : null;
        if (is_object($ctxController)) {
            $cls = get_class($ctxController);
            if ($cls === 'AdminImportController' || $cls === 'AdminImportControllerCore') {
                return true;
            }
        }

        // Signal 3 — debounce intra-requête (filet de sécurité pour les
        // imports via webservice, scripts, ou contrôleurs non standard)
        $now = time();
        if (self::$_bulkSaveTs === 0 || ($now - self::$_bulkSaveTs) > 10) {
            self::$_bulkSaveTs    = $now;
            self::$_bulkSaveCount = 1;
        } else {
            self::$_bulkSaveCount++;
            if (self::$_bulkSaveCount > 5) {
                return true;
            }
        }

        return false;
    }

    /**
     * US-PS-04.2 — Désactivation auto à la suppression d'un produit
     */
    public function hookActionProductDelete($params)
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey || empty($params['id_product'])) {
            return;
        }

        $product = ['id_product' => (int) $params['id_product'], 'active' => false];
        $this->_apiCallAsync('POST', '/products', ['products' => [$product]]);
    }

    /**
     * Compare les produits actifs de PrestaShop et RecoKit sans tenir compte
     * des exclusions de recommandation ni de la limite du forfait.
     */
    private function _refreshCatalogMismatchFlag(): void
    {
        $shopId = (int) $this->context->shop->id;
        $rows = Db::getInstance()->executeS(
            'SELECT p.id_product FROM `' . _DB_PREFIX_ . 'product` p '
            . 'INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps '
            . 'ON ps.id_product = p.id_product '
            . 'WHERE ps.id_shop = ' . $shopId . ' AND ps.active = 1 '
            . 'ORDER BY p.id_product ASC'
        );
        if (!is_array($rows)) {
            return;
        }

        $ids = array_map(static fn($row) => (string) $row['id_product'], $rows);
        sort($ids, SORT_STRING);
        $localFingerprint = hash('sha256', implode(',', $ids));
        $remote = $this->_apiCall('GET', '/catalog-status', [], 10);
        if (!is_array($remote) || ($remote['status'] ?? '') !== 'ok') {
            return;
        }

        $matches = (int) ($remote['active_product_count'] ?? -1) === count($ids)
            && hash_equals(
                $localFingerprint,
                (string) ($remote['active_product_fingerprint'] ?? '')
            );
        Configuration::updateValue('RECOKIT_CATALOG_MISMATCH', $matches ? 0 : 1);
    }

    /**
     * US-PS-04.3 — Sync commandes à la validation de paiement
     * Statut 2 = "Paiement accepté" dans PrestaShop (configurable)
     */
    public function hookActionOrderStatusUpdate($params)
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey) {
            return;
        }

        $newOrderState = $params['newOrderStatus'];
        // Statut "Paiement accepté" = id 2 par défaut dans PS
        $paidStatusId = (int) Configuration::get('PS_OS_PAYMENT');
        if ((int) $newOrderState->id !== $paidStatusId) {
            return;
        }

        $order    = $params['order'];
        $products = $order->getProducts();

        // Récupération du cookie de session RecoKit (optionnel pour attribution directe, null pour co-ventes globales)
        $sessionId = isset($_COOKIE[self::COOKIE_NAME]) ? $_COOKIE[self::COOKIE_NAME] : null;

        $lineItems = [];
        foreach ($products as $product) {
            $lineItems[] = [
                'id_product'           => (int) $product['product_id'],
                'quantity'             => (int) $product['product_quantity'],
                'unit_price_tax_incl'  => (float) $product['unit_price_tax_incl'],
            ];
        }

        $payload = [
            'order' => [
                'id_order'        => (int) $order->id,
                'id_customer'     => (int) $order->id_customer,
                'recokit_session' => $sessionId,
                'products'        => $lineItems,
            ],
        ];

        $this->_apiCallAsync('POST', '/orders', $payload);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Hooks — Widget Frontend (EPIC-PS-03)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * US-PS-03.1 — Injection du script JS sur les pages produit
     *
     * FIX #5 : guard sur getTemplateVarProduct() qui peut retourner false/null
     * sur certaines versions PS 1.7.
     */
    public function hookActionFrontControllerSetMedia($params)
    {
        $apiKey = Configuration::get('RECOKIT_API_KEY');
        if (!$apiKey) {
            return;
        }

        // FIX #5 : Utiliser Tools::getValue en priorité pour l'ID produit
        $productId = (int) Tools::getValue('id_product');
        if (!$productId && method_exists($this->context->controller, 'getTemplateVarProduct')) {
            $product   = $this->context->controller->getTemplateVarProduct();
            $productId = is_array($product) ? ($product['id_product'] ?? $product['id'] ?? '') : '';
        }

        Media::addJsDef([
            'recokitApiKey'    => $apiKey,
            'recokitProductId' => (string) $productId,
            'recokitLimit'     => (int) Configuration::get('RECOKIT_WIDGET_LIMIT') ?: 4,
            'recokitApiBase'   => self::getBrowserApiBaseUrl(true),
            'recokitCartProductIds' => $this->_getCartProductIds(),
        ]);

        // Injection du CSS du widget. Sans query string : les chemins
        // enregistrés via registerStylesheet/registerJavascript avec un "?v="
        // ne sont pas émis par PrestaShop (vérifié sur PS 8.1 : le CSS
        // n'apparaissait ni sur la home ni sur la page panier). Le cache-busting
        // est assuré par les inclusions directes des templates.
        $this->context->controller->registerStylesheet(
            'recokit-widget-css',
            'modules/' . $this->name . '/views/css/widget.css',
            ['media' => 'all', 'priority' => 150]
        );

        // Injection du JS du widget (chargé en defer)
        $this->context->controller->registerJavascript(
            'recokit-widget-js',
            'modules/' . $this->name . '/views/js/widget.js',
            ['position' => 'bottom', 'priority' => 200]
        );
    }

    /**
     * US-PS-03.2 — Conteneur HTML du widget via hook displayFooterProduct
     */
    public function hookDisplayFooterProduct($params)
    {
        return $this->_renderWidget($params);
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        // On désactive l'affichage sur la droite (AdditionalInfo) pour privilégier le dessous du produit (FooterProduct)
        return '';
    }

    /** Recommandations complémentaires sous le panier. */
    public function hookDisplayShoppingCartFooter($params)
    {
        return $this->_renderCartWidget('page');
    }

    /** Recommandations complémentaires dans la modal après ajout au panier. */
    public function hookDisplayCartModalFooter($params)
    {
        return $this->_renderCartWidget('modal');
    }

    private function _renderCartWidget($placement)
    {
        $apiKey = Configuration::get('RECOKIT_API_KEY');
        if (!$apiKey) {
            return '';
        }
        $this->context->smarty->assign([
            'recokit_cart_placement' => $placement,
            'recokit_api_key_json' => json_encode($apiKey),
            'recokit_api_base_json' => json_encode(self::getBrowserApiBaseUrl(true)),
            'recokit_cart_product_ids_json' => json_encode($this->_getCartProductIds()),
            'recokit_widget_css' => $this->_path . 'views/css/widget.css?v=1.3.3-bundle-cart',
            'recokit_widget_js' => $this->_path . 'views/js/widget.js?v=1.3.3-bundle-cart',
        ]);
        return $this->display(__FILE__, 'views/templates/hook/cart-widget.tpl');
    }

    private function _getCartProductIds()
    {
        $ids = [];
        if ($this->context->cart && $this->context->cart->id) {
            foreach ($this->context->cart->getProducts() as $product) {
                $id = (string) ($product['id_product'] ?? $product['product_id'] ?? '');
                if ($id !== '' && !in_array($id, $ids, true)) {
                    $ids[] = $id;
                }
            }
        }
        return $ids;
    }

    private function _renderWidget($params)
    {
        $apiKey = Configuration::get('RECOKIT_API_KEY');
        if (!$apiKey) {
            return '';
        }

        // Gestion du cookie de session RecoKit (US-PS-03.3)
        if (!isset($_COOKIE[self::COOKIE_NAME])) {
            $sessionId = $this->_generateUUID();
            setcookie(
                self::COOKIE_NAME,
                $sessionId,
                time() + self::COOKIE_LIFETIME,
                '/',
                '',
                true,
                false
            );
        }

        // Récupération de l'ID produit depuis l'URL ou les paramètres du hook
        $productId = (int) Tools::getValue('id_product');
        if (!$productId) {
            if (isset($params['product']) && is_array($params['product']) && !empty($params['product']['id_product'])) {
                $productId = $params['product']['id_product'];
            } elseif (isset($params['product']) && is_array($params['product']) && !empty($params['product']['id'])) {
                $productId = $params['product']['id'];
            } elseif ($this->context->controller && method_exists($this->context->controller, 'getTemplateVarProduct')) {
                $product = $this->context->controller->getTemplateVarProduct();
                $productId = is_array($product) ? ($product['id_product'] ?? $product['id'] ?? '') : '';
            }
        }

        $limit = (int) Configuration::get('RECOKIT_WIDGET_LIMIT') ?: 4;
        $apiBase = self::getBrowserApiBaseUrl(true);
        $moduleUri = $this->_path;

        // Variables JS inline (autonome, ne dépend plus de hookActionFrontControllerSetMedia)
        $inlineJs = '<script>'
            . 'if(typeof recokitApiKey===\'undefined\'){'
            . 'window.recokitApiKey=' . json_encode($apiKey) . ';'
            . 'window.recokitProductId=' . json_encode((string) $productId) . ';'
            . 'window.recokitLimit=' . (int) $limit . ';'
            . 'window.recokitApiBase=' . json_encode($apiBase) . ';'
            . '}'
            . '</script>' . "\n";

        // Inclusion directe du CSS et JS (fallback si hookActionFrontControllerSetMedia ne fire pas)
        $inlineJs .= '<link rel="stylesheet" href="' . $moduleUri . 'views/css/widget.css?v=1.3.3-bundle-cart">' . "\n";
        $inlineJs .= '<script src="' . $moduleUri . 'views/js/widget.js?v=1.3.3-bundle-cart"></script>' . "\n";

        $this->context->smarty->assign([
            'recokit_limit' => $limit,
        ]);

        return $inlineJs . $this->display(__FILE__, 'views/templates/hook/widget.tpl');
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers internes
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Retourne l'URL de base de l'API RecoKit.
     * Privilégie la valeur configurée en base de données, sinon utilise la constante.
     */
    public static function getApiBaseUrl(): string
    {
        $dbUrl = Configuration::get('RECOKIT_API_URL');
        if ($dbUrl) {
            return rtrim($dbUrl, '/');
        }
        return self::API_BASE_URL;
    }

    /**
     * Retourne l'URL de base de l'API RecoKit pour le navigateur (JS widget, iframe, checkout).
     * Gère la redirection d'IP Docker internes (172.x.x.x / host.docker.internal) vers localhost
     * ou le host de la boutique visitée si on est en environnement distant.
     */
    public static function getBrowserApiBaseUrl($includePath = true): string
    {
        $apiUrl = self::getApiBaseUrl();
        $parsedUrl = parse_url($apiUrl);
        if (!$parsedUrl) {
            return $apiUrl;
        }

        $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : 'https';
        $host   = isset($parsedUrl['host'])   ? $parsedUrl['host']   : 'api.recokit.fr';
        $port   = isset($parsedUrl['port'])   ? ':' . $parsedUrl['port'] : '';
        $path   = $includePath && isset($parsedUrl['path']) ? $parsedUrl['path'] : '';

        if ($host === 'host.docker.internal' || preg_match('/^172\./', $host)) {
            $shopUrl    = Tools::getShopDomainSsl(true);
            $shopParsed = parse_url($shopUrl);
            $shopHost   = isset($shopParsed['host']) ? $shopParsed['host'] : 'localhost';

            if ($shopHost === 'localhost' || $shopHost === '127.0.0.1'
                || preg_match('/^192\.168\./', $shopHost)
                || preg_match('/^10\./', $shopHost)
            ) {
                $host = 'localhost';
            } else {
                $host = $shopHost;
            }
        }

        return $scheme . '://' . $host . $port . $path;
    }

    /**
     * Normalise un produit PrestaShop vers le format attendu par l'API RecoKit.
     *
     * FIX #3 : instanciation unique de Product pour éviter deux requêtes SQL.
     */
    private function _normalizeProduct(array $product): array
    {
        $id     = $product['id_product'] ?? $product['id'] ?? 0;
        $langId = (int) Configuration::get('PS_LANG_DEFAULT');

        // FIX #3 : une seule instanciation, puis test de validité
        $productObj = new Product((int) $id, false, $langId);
        if (!Validate::isLoadedObject($productObj)) {
            $productObj = null;
        }

        // Catégories
        $categories = [];
        if ($productObj) {
            $cats       = Product::getProductCategoriesFull((int) $id, $langId);
            $categories = array_values(array_map(fn($c) => ['name' => $c['name']], $cats));
        }

        // Caractéristiques structurées PrestaShop : source officielle prioritaire
        // pour RecoKit, avant l'extraction de la fiche et les PDF fournisseur.
        $features = [];
        if ($productObj) {
            foreach (Product::getFrontFeaturesStatic($langId, (int) $id) as $feature) {
                if (!empty($feature['name']) && isset($feature['value']) && $feature['value'] !== '') {
                    $features[] = [
                        'name' => (string) $feature['name'],
                        'value' => (string) $feature['value'],
                    ];
                }
            }
        }

        // Images (générées avec le chemin physique pour contourner les problèmes de rewrite Nginx)
        $images      = [];
        $imageLinks  = Image::getImages($langId, (int) $id);
        $baseUrl     = rtrim(Tools::getShopDomainSsl(true), '/');
        foreach ($imageLinks as $img) {
            $id_image   = (string) $img['id_image'];
            $folderPath = implode('/', str_split($id_image));
            $images[]   = $baseUrl . '/img/p/' . $folderPath . '/' . $id_image . '-large_default.jpg';
        }

        // URL canonique + slug SEO (link_rewrite)
        // ATTENTION : $productObj->link_rewrite peut être une chaîne (quand le Product
        // est chargé avec un $id_lang précis) OU un tableau [id_lang => slug]. Accéder
        // avec [$langId] sur une chaîne déclenche l'indexage de caractères PHP :
        // "sac-a-main-grande-capacite-ref-1267"[1] => "a" — c'est la cause racine du
        // bug récurrent rewrite=a. On gère donc explicitement les deux formes.
        $linkRewrite = '';
        $productUrl  = '';
        if ($productObj) {
            $rawRewrite = isset($productObj->link_rewrite) ? $productObj->link_rewrite : '';
            if (is_array($rawRewrite)) {
                $linkRewrite = $rawRewrite[$langId]
                    ?? $rawRewrite[(int) Configuration::get('PS_LANG_DEFAULT')]
                    ?? '';
            } elseif (is_string($rawRewrite)) {
                $linkRewrite = $rawRewrite;
            }
            $productUrl = $this->context->link->getProductLink((int) $id, $linkRewrite, null, null, $langId);
        }

        // Product::getProducts() n'expose pas toujours `quantity`. Utiliser la
        // source de vérité PrestaShop évite alors de synchroniser tout le
        // catalogue avec un faux stock à zéro, ce qui masque les zones du
        // widget lorsque « afficher les produits hors stock » est désactivé.
        $quantity = $productObj
            ? (int) StockAvailable::getQuantityAvailableByProduct((int) $id, null, (int) $this->context->shop->id)
            : (int) ($product['quantity'] ?? 0);
        $outOfStock = $productObj && isset($productObj->out_of_stock)
            ? (int) $productObj->out_of_stock
            : (int) ($product['out_of_stock'] ?? 2);

        return [
            'id_product'        => (int) $id,
            'name'              => $product['name'] ?? '',
            'price'             => (float) ($product['price'] ?? 0),
            'description'       => $product['description'] ?? '',
            'description_short' => $product['description_short'] ?? '',
            'manufacturer_name' => $product['manufacturer_name'] ?? '',
            'reference'         => $product['reference'] ?? '',
            'ean13'             => $product['ean13'] ?? '',
            'active'            => (bool) ($product['active'] ?? true),
            'quantity'          => $quantity,
            'out_of_stock'      => $outOfStock,
            'categories'        => $categories,
            'features'          => $features,
            'images'            => $images,
            'tags'              => [],
            'link_rewrite'      => $linkRewrite,
            'product_url'       => $productUrl,
        ];
    }

    /**
     * Appel API RecoKit synchrone (pour la sync manuelle et le ping)
     */
    private function _apiCall(
        string $method,
        string $endpoint,
        array $payload = [],
        int $timeout = 30
    ): ?array
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey) {
            return null;
        }

        $url     = self::getApiBaseUrl() . $endpoint;
        $headers = [
            'Content-Type: application/json',
            'X-Api-Key: ' . $apiKey,
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300 && $response) {
            return json_decode($response, true);
        }

        Logger::addLog(
            '[RecoKit] API Error ' . $httpCode . ' on ' . $endpoint . ' — ' . $response,
            3, null, 'Module', $this->id
        );
        return null;
    }

    /**
     * Appel API RecoKit asynchrone (non-bloquant, pour les hooks)
     * Utilise un timeout très court pour ne pas bloquer le back-office.
     *
     * FIX #4 : log robuste quel que soit le type de payload (products ou orders).
     */
    private function _apiCallAsync(string $method, string $endpoint, array $payload = []): void
    {
        $apiKey = Configuration::get('RECOKIT_INTEGRATION_API_KEY');
        if (!$apiKey) {
            return;
        }

        $url     = self::getApiBaseUrl() . $endpoint;
        $headers = [
            'Content-Type: application/json',
            'X-Api-Key: ' . $apiKey,
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_TIMEOUT        => 5,  // fail rapide, non bloquant
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_NOSIGNAL       => 1,
        ]);

        curl_exec($ch);
        curl_close($ch);

        // FIX #4 : count() uniquement si la clé 'products' existe et est un tableau
        $itemCount = isset($payload['products']) && is_array($payload['products'])
            ? count($payload['products'])
            : 1;

        Logger::addLog(
            '[RecoKit] Async sync: ' . $endpoint . ' — ' . $itemCount . ' item(s)',
            1, null, 'Module', $this->id
        );
    }

    /**
     * Génère un UUID v4 pour le cookie de session.
     */
    private function _generateUUID(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
